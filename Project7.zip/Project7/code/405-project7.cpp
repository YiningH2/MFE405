// 405-project7.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <Eigen/Dense>
#include <iostream>

using Eigen::MatrixXd;
using Eigen::VectorXd;

// Function to appoximate N()
double approxN(double x)
{
	if (x < 0) {
		return (1 - approxN(x*(-1)));
	}
	double d[6] = { 0.0498673470,0.0211410061,0.0032776263,0.0000380036,0.0000488906,0.0000053830 };
	double sum = 1;
	for (int i = 0; i < 6; i++)
	{
		sum = sum + d[i] * pow(x, i + 1);
	}
	sum = pow(sum, -16.0) * 0.5;
	return 1 - sum;
}

double pricePutBS(double S_0, double T, double X, double r, double sigma)
{
	double d1 = (log(S_0 / X) + (r + sigma * sigma / 2) * T) / (sigma * sqrt(T));
	double d2 = d1 - sigma * sqrt(T);
	double call = S_0 * approxN(d1) - X * exp(-r * T) * approxN(d2);
	return call - S_0 + X * exp(-r * T);
}


double priceEuropeanOptionPut(double S0, double r, double sigma, double K, double T, double dx, double dt, int method)
{
	double S0_ori = S0; double K_ori = K;
	K = log(K); S0 = log(S0);
	int m = (int)(T / dt);
	int n = 50;

	double* XT = new double[2*n+1];
	for (int i = 0; i <= n; i++)
		XT[i] = S0 + (n - i) * dx;
	for (int i = 1; i <= n; i++)
		XT[i+n] = S0 - (i) * dx;

	double res;
	VectorXd Bi = VectorXd::Zero(2 * n + 1);
	MatrixXd A = MatrixXd::Zero(2 * n + 1, 2 * n + 1);
	VectorXd Fi = VectorXd::Zero(2 * n + 1);

	if (method == 0)	// explicit
	{
		// Construct B
		Bi(2 * n) = exp(XT[0]) - exp(XT[1]);

		// Construct A
		double Pu = dt * ((sigma*sigma) / (2 * dx * dx) + (r - sigma * sigma / 2) / (2 * dx));
		double Pm = 1 - (dt * (sigma * sigma)) / (dx * dx) - r * dt;
		double Pd = dt * ((sigma*sigma) / (2 * dx * dx) - (r - sigma * sigma / 2) / (2 * dx));
		A(0, 0) = Pu; A(0, 1) = Pm; A(0, 2) = Pd;
		for (int i = 0; i < 2 * n - 1; i++)
		{
			A(i + 1, i) = Pu; A(i + 1, 1 + i) = Pm; A(i + 1, 2 + i) = Pd;
		}
		A(2 * n, 2 * n - 2) = Pu; A(2 * n, 2 * n - 1) = Pm; A(2 * n, 2 * n) = Pd;

		// Construct F
		for (int i = 0; i < 2 * n + 1; i++)
		{
			double payoff = K_ori - exp(XT[i]);
			Fi(i) = payoff > 0 ? payoff : 0;
		}
		for (int i = 0; i < m; i++)
			Fi = A * Fi + Bi;
		res = Fi(n);
	}
	else if (method == 1)	// Implicit
	{
		// Construct A
		double Pu = -0.5 * dt * ((sigma*sigma) / (dx * dx) + (r - sigma * sigma / 2.0) / dx);
		double Pm = 1 + (dt * (sigma * sigma)) / (dx * dx) + r * dt;
		double Pd = -0.5 * dt * ((sigma*sigma) / (dx * dx) - (r - sigma * sigma / 2.0) / dx);
		A(0, 0) = 1; A(0, 1) = -1; 
		for (int i = 0; i < 2 * n - 1; i++)
		{
			A(i + 1, i) = Pu; A(i + 1, 1 + i) = Pm; A(i + 1, 2 + i) = Pd;
		}
		A(2 * n, 2 * n - 1) = 1; A(2 * n, 2 * n) = -1;
		A = A.inverse();

		// Construct F at m
		for (int i = 0; i < 2 * n + 1; i++)
		{
			double payoff = K_ori - exp(XT[i]);
			Fi(i) = payoff > 0 ? payoff : 0;
		}

		Bi(0) = 0;
		Bi(2 * n) = exp(XT[2 * n]) - exp(XT[2 * n - 1]);
		for (int j = 0; j < m; j++)
		{
			// Construct B
			for (int i = 1; i < 2 * n; i++) Bi(i) = Fi(i);
			//Fi = A.inverse() * Bi; // Fm-1
			Fi = A * Bi;
		}

		res = Fi(n);
	}
	else // Crank-Nicolson Finite Difference
	{
		// Construct A
		double Pu = -0.25 * dt * ((sigma*sigma) / (dx * dx) + (r - sigma * sigma / 2.0) / dx);
		double Pm = 1 + (dt * (sigma * sigma)) / (2 * dx * dx) + r * dt / 2.0;
		double Pd = -0.25 * dt * ((sigma*sigma) / (dx * dx) - (r - sigma * sigma / 2.0) / dx);
		A(0, 0) = 1; A(0, 1) = -1;
		for (int i = 0; i < 2 * n - 1; i++)
		{
			A(i + 1, i) = Pu; A(i + 1, 1 + i) = Pm; A(i + 1, 2 + i) = Pd;
		}
		A(2 * n, 2 * n - 1) = 1; A(2 * n, 2 * n) = -1;
		A = A.inverse();
		// Construct F at m
		for (int i = 0; i < 2 * n + 1; i++)
		{
			double payoff = K_ori - exp(XT[i]);
			Fi(i) = payoff > 0 ? payoff : 0;
		}

		Bi(0) = 0;
		Bi(2 * n) = exp(XT[2 * n]) - exp(XT[2 * n - 1]);
		for (int j = 0; j < m; j++)
		{
			// Construct B
			for (int i = 1; i < 2 * n; i++) 
				Bi(i) = -Pu * Fi(i-1) - (Pm - 2) * Fi(i) - Pd * Fi(i+1);
			//Fi = A.inverse() * Bi; // Fm-1
			Fi = A * Bi; // Fm-1
		}
		res = Fi(n);
	}
	delete[] XT;
	//Bi.resize(0, 0);
	A.resize(0, 0);
	//Fi.resize(0, 0);

	return res;
}

double priceAmericanOption(double S0, double r, double sigma, double K, double T, double dx, double dt, int type, int method)
{
	// Type 0 - Call, 1 - Put
	int m = (int)(T / dt);
	int n = 50;

	double* XT = new double[2 * n + 1];
	for (int i = 0; i <= n; i++)
		XT[i] = S0 + (n - i) * dx;
	for (int i = 1; i <= n; i++)
		XT[i + n] = S0 - (i)* dx;
	
	double res;
	VectorXd Bi = VectorXd::Zero(2 * n + 1);
	MatrixXd A = MatrixXd::Zero(2 * n + 1, 2 * n + 1);
	VectorXd Fi = VectorXd::Zero(2 * n + 1);

	if (method == 0)	// explicit
	{
		// Construct B
		if (type == 0) // If Call
			Bi(0) = XT[0] - XT[1];
		else // If put
			Bi(2 * n) = XT[0] - XT[1];

		// Construct A
		double S = XT[0];
		A(0, 0) = dt * ((sigma * sigma * S * S) / (2 * dx * dx) + (r * S) / (2 * dx));
		A(0, 1) = 1 - (dt * (sigma * sigma * S * S)) / (dx * dx) - r * dt;
		A(0, 2) = dt * ((sigma*sigma * S * S) / (2 * dx * dx) - (r * S) / (2 * dx));

		for (int i = 0; i < 2 * n - 1; i++)
		{
			S = XT[i + 1];
			A(i + 1, i) = dt * ((sigma * sigma * S * S) / (2 * dx * dx) + (r * S) / (2 * dx));
			A(i + 1, 1 + i) = 1 - (dt * (sigma * sigma * S * S)) / (dx * dx) - r * dt;
			A(i + 1, 2 + i) = dt * ((sigma*sigma * S * S) / (2 * dx * dx) - (r * S) / (2 * dx));
		}

		S = XT[2 * n];
		A(2 * n, 2 * n - 2) = dt * ((sigma * sigma * S * S) / (2 * dx * dx) + (r * S) / (2 * dx));
		A(2 * n, 2 * n - 1) = 1 - (dt * (sigma * sigma * S * S)) / (dx * dx) - r * dt;
		A(2 * n, 2 * n) = dt * ((sigma*sigma * S * S) / (2 * dx * dx) - (r * S) / (2 * dx));

		// Construct F
		for (int i = 0; i < 2 * n + 1; i++)
		{
			double payoff;
			if (type == 0) // If Call
				payoff = XT[i] - K;
			else // If put
				payoff = K - XT[i];
			Fi(i) = payoff > 0 ? payoff : 0;
		}
		for (int i = 0; i < m; i++)
		{
			Fi = A * Fi + Bi;
			for (int j = 0; j < 2 * n + 1; j++)
			{
				if (type == 0) // If Call
					Fi(j) = Fi(j) > (XT[j] - K) ? Fi(j) : (XT[j] - K);
				else // If put
					Fi(j) = Fi(j) > (K - XT[j]) ? Fi(j) : (K - XT[j]);
			}
		}
		res = Fi(n);
	}
	else if (method == 1)	// Implicit
	{
		// Construct A
		A(0, 0) = 1; A(0, 1) = -1;
		for (int i = 0; i < 2 * n - 1; i++)
		{
			double S = XT[i + 1];
			A(i + 1, i) = - 0.5 * dt * ((sigma*sigma * S * S) / (dx * dx) + (r * S) / dx);
			A(i + 1, 1 + i) = 1 + (dt * (sigma * sigma * S * S)) / (dx * dx) + r * dt;
			A(i + 1, 2 + i) = -0.5 * dt * ((sigma*sigma * S * S) / (dx * dx) - (r * S) / dx);
		}
		A(2 * n, 2 * n - 1) = 1; A(2 * n, 2 * n) = -1;
		A = A.inverse();

		// Construct F at m
		for (int i = 0; i < 2 * n + 1; i++)
		{
			double payoff;
			if (type == 0) // If Call
				payoff = XT[i] - K;
			else
				payoff = K - XT[i];
			Fi(i) = payoff > 0 ? payoff : 0;
		}


		if (type == 0) // If Call
			Bi(0) = XT[0] - XT[1];
		else // If put
			Bi(2 * n) = XT[2 * n] - XT[2 * n - 1];

		for (int i = 0; i < m; i++)
		{
			// Construct B
			for (int j = 1; j < 2 * n; j++) 
				Bi(j) = Fi(j);
			Fi = A * Bi; // Fm-1
			for (int j = 0; j < 2 * n + 1; j++)
			{
				if (type == 0) // If Call
					Fi(j) = Fi(j) > (XT[j] - K) ? Fi(j) : (XT[j] - K);
				else // If put
					Fi(j) = Fi(j) > (K - XT[j]) ? Fi(j) : (K - XT[j]);
			}
		}

		res = Fi(n);
	}
	else // Crank-Nicolson Finite Difference
	{
		// Construct A
		A(0, 0) = 1; A(0, 1) = -1;
		for (int i = 0; i < 2 * n - 1; i++)
		{
			double S = XT[i + 1];
			A(i + 1, i) = -0.25 * dt * ((sigma*sigma * S * S) / (dx * dx) + (r * S) / dx);
			A(i + 1, 1 + i) = 1 + (dt * (sigma * sigma * S * S)) / (2 * dx * dx) + r * dt / 2.0;
			A(i + 1, 2 + i) = -0.25 * dt * ((sigma*sigma * S * S) / (dx * dx) - (r * S) / dx);
		}
		A(2 * n, 2 * n - 1) = 1; A(2 * n, 2 * n) = -1;

		// Construct F at m
		for (int i = 0; i < 2 * n + 1; i++)
		{
			double payoff;
			if (type == 0) // If Call
				payoff = XT[i] - K;
			else
				payoff = K - XT[i];
			Fi(i) = payoff > 0 ? payoff : 0;
		}

		if (type == 0) // If Call
			Bi(0) = XT[0] - XT[1];
		else // If put
			Bi(2 * n) = XT[2 * n] - XT[2 * n - 1];

		A = A.inverse();
		for (int j = 0; j < m; j++)
		{
			// Construct B
			for (int i = 1; i < 2 * n; i++)
			{
				double S = XT[i];
				double Pu = -0.25 * dt * ((sigma*sigma * S * S) / (dx * dx) + (r * S) / dx);
				double Pm = 1 + (dt * (sigma * sigma * S * S)) / (2 * dx * dx) + r * dt / 2.0;
				double Pd = -0.25 * dt * ((sigma*sigma * S * S) / (dx * dx) - (r * S) / dx);
				Bi(i) = -Pu * Fi(i - 1) - (Pm - 2) * Fi(i) - Pd * Fi(i + 1);
			}
				
			Fi = A * Bi; // Fm-1
			for (int j = 0; j < 2 * n + 1; j++)
			{
				if (type == 0) // If Call
					Fi(j) = Fi(j) > (XT[j] - K) ? Fi(j) : (XT[j] - K);
				else // If put
					Fi(j) = Fi(j) > (K - XT[j]) ? Fi(j) : (K - XT[j]);
			}
		}
		res = Fi(n, 0);
	}
	delete[] XT;
	A.resize(0, 0);


	return res;
}



int main()
{
	// Problem 1
	std::cout << "Problem 1: " << std::endl;
	double sigma = 0.2;
	double dt = 0.002;

	/*
	for (int S = 4; S <= 16; S++)
	{
		double BS = pricePutBS(S, 0.5, 10, 0.04, sigma);
		std::cout << "For S0 = " << S << ", the BS price is " << BS << std::endl;
		double res[3] = {};
		for (int j = 0; j < 3; j++)
		{
			res[j] = priceEuropeanOptionPut(S, 0.04, sigma, 10, 0.5, sigma * sqrt(4 * dt), dt, j);
			std::cout << res[j] << "	";
		}
		std::cout << std::endl;
		for (int j = 0; j < 3; j++)	
			std::cout << abs(res[j] - BS) << "	";
		std::cout << std::endl;
	}
*/



	std::cout << "Problem 2: " << std::endl;

	std::cout << "American Call Option " << std::endl;
	for (int j = 0; j < 3; j++)
	{
		std::cout << "For method " << j << std::endl;
		for (int S = 4; S <= 16; S++)
		{
			std::cout << priceAmericanOption(S, 0.04, 0.2, 10, 0.5, 1.25, dt, 0, j) << ", ";
		}
		std::cout << std::endl;
	}

	std::cout << "American Put Option " << std::endl;
	for (int j = 0; j < 3; j++)
	{
		std::cout << "For method " << j << std::endl;
		for (int S = 4; S <= 16; S++)
		{
			std::cout << priceAmericanOption(S, 0.04, 0.2, 10, 0.5, 1.25, dt, 1, j) << ",";
		}
		std::cout << std::endl;
	}
	
}
