#pragma once

class Generater
{
public:
	Generater(int x);
	~Generater();
	void setSeed(int x);
	double* generateUniforms(int size);

	double calculateMean(double nums[], int total);
	double calculateSD(double nums[], int total, double mean);

	double cov(double x[], double y[], int total);
	int seed = 0;
};

