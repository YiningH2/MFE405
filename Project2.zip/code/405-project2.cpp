// 405-project2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#define _USE_MATH_DEFINES

#include <iostream>
#include <algorithm>
#include <vector>
#include <random>
#include <cstdlib>
#include <ctime>
#include <time.h>
#include <fstream>
#include <math.h> 
#include <chrono> 
#include "Generater.h"

std::vector<std::vector<double>> generateNormals(Generater* g, int size) 
{
	srand(time(0));
	int random = rand();
	g->setSeed((g->seed + random) % 300);
	double* uniform_p1 = g->generateUniforms(size);
	std::vector<double> normal_PM_1;
	std::vector<double> normal_PM_2;
	for (int i = 0; i < size / 2; i++)
	{
		double U1 = uniform_p1[i];
		double U2 = uniform_p1[size - 1 - i];
		double V1 = 2 * U1 - 1;
		double V2 = 2 * U2 - 1;
		double W = V1 * V1 + V2 * V2;
		double Z1;
		double Z2;
		if (W < 1)
		{
			Z1 = V1 * sqrt((-2.0 * log(W)) / W);
			Z2 = V2 * sqrt((-2.0 * log(W)) / W);
			normal_PM_1.push_back(Z1);
			normal_PM_2.push_back(Z2);
		}
	}
	std::vector<std::vector<double>> v;
	v.push_back(normal_PM_1);
	v.push_back(normal_PM_2);

	delete[]uniform_p1;
	uniform_p1 = NULL;
	return v;
}

// Function to output data to a txt, given the filename, array and size
template <class T>
void outputFile(std::string filename, T arr[], int size)
{
	std::ofstream myfile(filename);
	if (myfile.is_open())
	{
		for (int count = 0; count < size; count++)
		{
			myfile << arr[count];
			if (count != (size - 1))
				myfile << "	";
		}
		myfile << '\n';
		myfile.close();
	}
}

int main()
{
	// Initializing
	int seed;
	std::cout << "Please enter the seed: ";
	std::cin >> seed;
	std::cout << "The seed you enter is: " << seed << std::endl;
	
	Generater* g = new Generater(seed);
	g->setSeed(seed);
	// ************************************************************
	// Problem 1
	// Generate 2 1000 variables normal by Polar-Marsaglia method 
	static std::vector<std::vector<double>> v = generateNormals(g, 10000);
	static std::vector<double> normal_PM_1 = v[0];
	static std::vector<double> normal_PM_2 = v[1];

	static double X_p1[1000] = {};
	static double Y_p1[1000] = {};

	double a = -0.7;
	double b = sqrt(1-a*a);
	for (int i = 0; i < 1000; i++) 
	{
		// Generate both X and Ys
		X_p1[i] = 0 + 1 * normal_PM_1[i];
		Y_p1[i] = 0 + a * normal_PM_1[i] + b * normal_PM_2[i];
	}

	double X_hat = g->calculateMean(X_p1, 1000);	// calculate means of X and Y
	double Y_hat = g->calculateMean(Y_p1, 1000);

	double nom = 0;
	for (int i = 0; i < 1000; i++)
	{
		double L_nom = X_p1[i] - X_hat;
		double R_nom = Y_p1[i] - Y_hat;
		nom = nom + L_nom * R_nom;
	}
	nom = nom / double(1000 - 1);	// calculate the nominator

	double L_denom = 0;
	double R_denom = 0;
	for (int i = 0; i < 1000; i++)
	{
		L_denom = L_denom + (X_p1[i] - X_hat) * (X_p1[i] - X_hat) / double(1000 - 1);
		R_denom = R_denom + (Y_p1[i] - Y_hat) * (Y_p1[i] - Y_hat) / double(1000 - 1);
	}
	double denom = sqrt(L_denom) * sqrt(R_denom); // calculate the denominator
	double rou = nom / denom;
	std::cout << "Problem 1:" << std::endl;
	std::cout << rou << std::endl;


	// ************************************************************
	// Problem 2
	// Generate two new normally distributed vectors
	v = generateNormals(g, 100000);
	normal_PM_1 = v[0];
	normal_PM_2 = v[1];

	a = 0.6;
	b = sqrt(1 - a * a);
	for (int i = 0; i < 1000; i++)
	{
		X_p1[i] = 0 + 1 * normal_PM_1[i];
		Y_p1[i] = 0 + a * normal_PM_1[i] + b * normal_PM_2[i];
	}

	double result_p2 = 0;
	for (int i = 0; i < 1000; i++)
	{
		double t = X_p1[i] * X_p1[i] * X_p1[i] + sin(Y_p1[i]) + X_p1[i] * X_p1[i] * Y_p1[i];
		if (t > 0)
		{
			result_p2 = result_p2 + t;  // Make sure it is larger than 0, otherwise do nothing
		}
	}
	result_p2 = result_p2 / 1000.0;
	std::cout << "Problem 2:" << std::endl;
	std::cout << result_p2 << std::endl;


	// ************************************************************
	// Problem 3
	// (a) 
	// generate 2 new normally distributed variables
	srand(time(0));
	int random = rand();
	g = new Generater(seed + random);
	v = generateNormals(g, 120000);
	static std::vector<double> normal_PM_3 = v[0];
	static std::vector<double> normal_PM_4 = v[1];
	int min_size = std::min(normal_PM_1.size(), normal_PM_3.size()); // make sure not go out of bounds

	// Ea1
	double Ea1 = 0;       
	double* Ea1_array = new double[min_size];
	double* Ea2_array = new double[min_size];
	double* Ea3_array = new double[min_size];
	double* Ea4_array = new double[min_size];

	for (int i = 0; i < min_size; i++)
	{
		double w5 = sqrt(5) * normal_PM_1[i];
		Ea1_array[i] = (w5 * w5 + sin(w5)) / double(min_size);
		Ea1 = Ea1 + Ea1_array[i];
	}

	// Ea2 Ea3 Ea4
	double Ea2 = 0;	double Ea3 = 0;	double Ea4 = 0;
	for (int i = 0; i < min_size; i++)
	{
		// Ea2
		double w0_5 = sqrt(0.5) * normal_PM_2[i];
		Ea2_array[i] = (exp(0.5 / 2) * cos(w0_5)) / double(min_size);
		Ea2 = Ea2 + Ea2_array[i];
		// Ea3
		double w3_2 = sqrt(3.2) * normal_PM_3[i];
		Ea3_array[i] = (exp(3.2 / 2) * cos(w3_2)) / double(min_size);
		Ea3 = Ea3 + Ea3_array[i];

		// Ea4
		double w6_5 = sqrt(6.5) * normal_PM_4[i];
		Ea4_array[i] = (exp(6.5 / 2) * cos(w6_5)) / double(min_size);
		Ea4 = Ea4 + Ea4_array[i];
	}


	std::cout << "Problem 3:" << std::endl;
	std::cout << "(a)";
	std::cout << " Ea1: " << Ea1 << ", Ea2: " << Ea2 << ", Ea3: " << Ea3 << ", Ea4: " << Ea4 << std::endl;

	// (b) Relax to Wt^2 + sin(Wt)
	double* uni_p3 = g->generateUniforms(min_size);

	// Eb1
	double* Eb1_array = new double[min_size];
	double Eb1 = 0;
	for (int i = 0; i < min_size; i++)
	{
		double w5 = sqrt(5) * normal_PM_1[i];
		Eb1_array[i] = (w5 * w5 - 5) / double(min_size);
		Eb1 = Eb1 + Eb1_array[i];
	}
	double ss = g->calculateSD(Eb1_array, min_size, g->calculateMean(Eb1_array, min_size));
	double varvar = ss * ss;
	double gamma = g->cov(Ea1_array, Eb1_array, min_size) / varvar;
	Eb1 = Ea1 - gamma * Eb1;

	// Eb2
	double* Eb2_array = new double[min_size];
	double* Eb3_array = new double[min_size];
	double* Eb4_array = new double[min_size];
	double Eb2 = 0;	double Eb3 = 0;	double Eb4 = 0;
	for (int i = 0; i < min_size; i++)
	{
		double w5 = sqrt(0.5) * normal_PM_1[i];
		Eb2_array[i] = (w5 * w5 - 0.5) / double(min_size);
		Eb2 = Eb2 + Eb2_array[i];

		w5 = sqrt(3.2) * normal_PM_1[i];
		Eb3_array[i] = (w5 * w5 - 3.2) / double(min_size);
		Eb3 = Eb3 + Eb3_array[i];

		w5 = sqrt(6.5) * normal_PM_1[i];
		Eb3_array[i] = (w5 * w5 - 6.5) / double(min_size);
		Eb4 = Eb4 + Eb4_array[i];
	}
	ss = g->calculateSD(Eb2_array, min_size, g->calculateMean(Eb2_array, min_size));
	varvar = ss * ss;
	gamma = g->cov(Ea2_array, Eb2_array, min_size) / varvar;
	Eb2 = Ea2 - gamma * Eb2;

	ss = g->calculateSD(Eb3_array, min_size, g->calculateMean(Eb3_array, min_size));
	varvar = ss * ss;
	gamma = g->cov(Ea3_array, Eb3_array, min_size) / varvar;
	Eb3 = Ea3 - gamma * Eb3;

	ss = g->calculateSD(Eb4_array, min_size, g->calculateMean(Eb4_array, min_size));
	varvar = ss * ss;
	gamma = g->cov(Ea3_array, Eb4_array, min_size) / varvar;
	Eb4 = Ea4 - gamma * Eb4;

	
	
	std::cout << "Eb1: " << Eb1 << ", Eb2: " << Eb2 << ", Eb3: " << Eb3 << ", Eb4: " << Eb4 << std::endl;


	// ************************************************************
	// Problem 4
	// (a) 
	double r = 0.04;
	double sigma = 0.2;
	double S0 = 88;
	double X = 100;
	double T = 5;
	double lhs = exp((-1) * r * T) /  (double)min_size;
	double Ca1 = 0;	double Ca2 = 0;
	for (int i = 0; i < min_size; i++)
	{
		double ST = S0 * exp( (r-sigma*sigma/2.0)* T + sigma * sqrt(T) * normal_PM_2[i]) - X;
		if (ST < 0)	// make sure non negative
			ST = 0;
		Ca1 = Ca1 + ST;
		ST = S0 * exp((r - sigma * sigma / 2.0) * T + sigma * sqrt(T) * normal_PM_3[i]) - X; // Do another simulation at the same time, different normals
		if (ST < 0)
			ST = 0;
		Ca2 = Ca2 + ST;
	}
	Ca1 = Ca1 * lhs;
	Ca2 = Ca2 * lhs;
	std::cout << "Problem 4:" << std::endl;
	std::cout << "(a)";
	std::cout << " Ca1: " << Ca1 << " Ca2: " << Ca2 << std::endl;

	// (b) 
	double Cb1 = 0;	double Cb2 = 0;
	v = generateNormals(g, 80000 + min_size);
	normal_PM_2 = v[0];
	for (int i = 0; i < min_size; i++)
	{
		double ST = S0 * exp((r - sigma * sigma / 2.0)* T + sigma * sqrt(T) * normal_PM_2[i]) - X;
		if (ST < 0)	// make sure non negative
			ST = 0;
		Cb1 = Cb1 + ST;
		double ST2 = S0 * exp((r - sigma * sigma / 2.0)* T + sigma * sqrt(T) * (-1) * normal_PM_2[i]) - X;
		if (ST2 < 0)	// make sure non negative
			ST2 = 0;
		Cb2 = Cb2 + ST2;
	}
	Cb1 = Cb1 * lhs;
	Cb2 = Cb2 * lhs;
	Cb1 = (Cb1 + Cb2) / 2;
	std::cout << "Problem 4:" << std::endl;
	std::cout << "(b) BS gives: 18.28; ";
	std::cout << " Cb1: " << Cb1 << std::endl;



	// ************************************************************
	// Problem 5
	// (a) 
	r = 0.04;
	sigma = 0.18;
	//sigma = 0.35;
	S0 = 88;
	int numSimulation = 1000;
	double Sn_p5[10] = {};
	for (int n = 1; n <= 10; n++) 
	{	// for each n
		double Sn = 0;
		v = generateNormals(g, 100000 + n * 10);
		normal_PM_3 = v[0];
		for (int i = 0; i < numSimulation; i++)	// do m times of simulation
		{
			double ST = S0 * exp((r - sigma * sigma / 2.0) * n + sigma * sqrt(n) * normal_PM_3[i]);
			Sn = Sn + ST;
		}
		Sn = Sn / double(numSimulation);
		Sn_p5[n - 1] = Sn;
	}
	outputFile("p5-a.txt", Sn_p5,10);
		
	// (b)
	double delta_t = 10.0 / 1000.0;
	double sqrt_delta_t = sqrt(delta_t);
	std::vector<std::vector<double>> paths;
	for (int path = 0; path < 6; path++)
	{
		std::vector<double> current_path;
		double STm1 = S0;
		current_path.push_back(S0);
		v = generateNormals(g, 100000+path*1000);	// generate new normally distributed variables
		normal_PM_3 = v[0];
		for (int i = 1; i <= 1000; i++)
		{
			double ST = STm1 * exp((r - sigma * sigma / 2.0) * (delta_t) + sigma * sqrt_delta_t * normal_PM_3[i]);
			STm1 = ST;
			current_path.push_back(ST);
		}
		paths.push_back(current_path);
	}

	// Output file
	std::ofstream myfile("p5-b.txt");
	if (myfile.is_open())
	{
		for (int count = 0; count < 6; count++)
		{
			std::vector<double> current = paths[count];
			for (int i = 0; i < 1001; i++)
			{
				myfile << current[i];
				if (i != 1000)
					myfile << "	";
			}
			myfile << '\n';
		}
		myfile.close();
	}

	// ************************************************************
	// Problem 6
	int intervals = 10000;
	double delta = 1.0 / double(intervals);
	// (a)
	double y0 = 0;
	double x_euler = 0;
	for (int i = 0; i < intervals; i++)
	{	// calculate the area of each little rectangle
		double y1 = y0 + sqrt(1 - x_euler * x_euler) * delta;
		x_euler = x_euler + delta;
		y0 = y1;
	}
	double Ia = y0 * 4;
	std::cout << "Problem 6:" << std::endl;
	std::cout << "(a)";
	std::cout << " The integral is: " << Ia << std::endl;

	// (b)
	// Generate new Uniformly distributed variables
	double* uni_p6 = g->generateUniforms(intervals);
	double Ib = 0;
	for (int i = 0; i < intervals; i++)
	{
		Ib = Ib + sqrt(1 - uni_p6[i] * uni_p6[i]);
	}

	Ib = Ib * 4 / intervals;
	std::cout << "(b)";
	std::cout << " The integral is: " << Ib << std::endl;

	// (c)
	// Generate Uniforms
	uni_p6 = g->generateUniforms(intervals+1);
	Ib = 0;
	for (int i = 0; i < intervals; i++)
	{
		double temp = sqrt(1 - uni_p6[i] * uni_p6[i]) / ((1 - 0.74 * uni_p6[i] * uni_p6[i]) / (1 - 0.74 / 3));
		Ib = Ib + temp;
	}

	Ib = Ib * 4 / intervals;
	std::cout << "(c)";
	std::cout << " The integral is: " << Ib << std::endl;

	delete[] uni_p6;
	uni_p6 = NULL;
}
