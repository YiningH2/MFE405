
data_a = read.delim("p5-a.txt",header = FALSE, dec = ".")
data_a = t(data_a)
x = seq(1, 10, by=1)
plot(x,data_a,main = "Plot for Question 5 - a",col = "blue",type='l')


data = read.delim("p5-b.txt",header = FALSE, dec = ".")
data = t(data)
data = t(data)
x = seq(0, 10, by=0.01)
plot(x,data[1,],main = "Plot for Question 5 - c",type = "l",ylim = c(50,300))
for (i in 2:6) {
  lines(x,data[i,])
}


data_a = read.delim("p5-a.txt",header = FALSE, dec = ".")
data_a = t(data_a)
x = seq(1, 10, by=1)
lines(x,data_a,col = "red",ylim = c(50,400))

