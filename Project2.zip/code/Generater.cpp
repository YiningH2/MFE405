#include "Generater.h"
#include <math.h> 


Generater::Generater(int x)
{
	seed = x;
}


Generater::~Generater()
{
}

void Generater::setSeed(int x)
{
	seed = x;
}

double* Generater::generateUniforms(int size)
{
	long long a = (long long)pow(7, 5);
	long long m = (long long)pow(2, 31) - 1;

	long long* nums = new long long[size]; // an array to store all values calculated
	nums[0] = (a * seed) % m;
	for (int i = 1; i < size; i++)
	{
		nums[i] = (a * nums[i - 1]) % m;       
	}

	double* uniformNums = new double[size];
	for (int i = 0; i < size; i++)
	{
		// Divide by m to get the Uniforms btw 0 and 1
		uniformNums[i] = (double)nums[i] / (double)m;
	}
	// Clean the data
	delete[] nums;
	nums = NULL;
	return uniformNums;
}


double Generater::calculateMean(double nums[], int total)
{
	// Function to calculate the mean of an array, given the size
	double mean = 0;
	for (int i = 0; i < total; i++)
	{
		mean = mean + nums[i];
	}
	mean = mean / total;
	return mean;
}

double Generater::calculateSD(double nums[], int total, double mean)
{
	// Function to calculate the sd of an array, given the size and mean
	double sd = 0;
	for (int i = 0; i < total; i++)
	{
		sd = sd + (nums[i] - mean) * (nums[i] - mean);
	}
	sd = sqrt(sd / total);
	return sd;
}

double Generater::cov(double x[], double y[], int total)
{
	double c = 0;
	double x_mean = calculateMean(x, total);
	double y_mean = calculateMean(y, total);
	for (int i = 0; i < total; i++)
	{
		c = c + (x[i] - x_mean) * (y[i] - y_mean);
	}
	c = c / double(total);
	return c;
}