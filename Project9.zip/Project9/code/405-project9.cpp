// 405-project9.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Generater.h"
#include <math.h>
#include <algorithm>


double** simulateInterestRate(int numOfPaths, double r0, double Years, double sigma, double Kappa, double ru, double x)
{
	Generater* g = new Generater(2);
	double** interestRate = new double*[numOfPaths];

	int numOfInterval = Years * 252;
	double delta = Years / (double)numOfInterval;

	for (int i = 0; i < numOfPaths; i++)
	{
		interestRate[i] = new double[numOfInterval + 1];
		double* normals = g->generateDefaultNormal(numOfInterval + 1);
		interestRate[i][0] = r0;
		for (int j = 1; j <= numOfInterval; j++)
		{
			double rt = interestRate[i][j - 1];
			interestRate[i][j] = rt + Kappa * (ru - rt) * delta + sigma * sqrt(rt) * sqrt(delta) * normals[j];
			interestRate[i][j] = std::max(interestRate[i][j], 0.0);
		}
		for (int j = 0; j <= numOfInterval; j++)
		{
			interestRate[i][j] = interestRate[i][j] + x;
		}
		delete[] normals;
	}
	delete g;
	return interestRate;
}

double discountC(double** ir, double C, int month, int numOfPaths)
{
	double delta = 1.0/252.0;
	int days = month * 21;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double sum = 0;
		for (int j = 0; j <= days; j++)
			sum += ir[i][j];
		R[i] = sum * delta * (-1);
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]);
	res = res / (double)numOfPaths * C;
	delete[] R;
	return res;

}

double priceDiscountBondExplicitC(double FV, double** irtT, int t, double sigma, double Kappa, double ru,int numOfPaths)
{
	double h1 = sqrt(Kappa * Kappa + 2.0 * sigma * sigma);
	double h2 = (h1 + Kappa) / 2.0;
	double h3 = (2 * Kappa * ru) / (sigma * sigma);

	double duration = 10.0;
	double B = (exp(h1 * duration) - 1) / (h2 * (exp(h1 * duration) - 1) + h1);
	double temp = (h1 * exp(h2 * duration)) / (h2 * (exp(h1 * duration) - 1) + h1);
	double A = pow(temp, h3);

	double price = 0;
	for (int i = 0; i < numOfPaths; i++)
	{
		double rT = irtT[i][t * 21];
		double p = A * exp(-B * rT) * FV;
		price += p;
	}
	price = price / (double)numOfPaths;
	return price;
}
/*

double** simulateInterestRate(int numOfPaths, double r0, double Years, double sigma, double Kappa, double ru, double x)
{
	Generater* g = new Generater(2);
	double** interestRate = new double*[numOfPaths];

	int numOfInterval = Years * 12;
	double delta = Years / (double)numOfInterval;

	for (int i = 0; i < numOfPaths; i++)
	{
		interestRate[i] = new double[numOfInterval + 1];
		double* normals = g->generateDefaultNormal(numOfInterval + 1);
		interestRate[i][0] = r0;
		for (int j = 1; j <= numOfInterval; j++)
		{
			double rt = interestRate[i][j - 1];
			interestRate[i][j] = rt + Kappa * (ru - rt) * delta + sigma * sqrt(rt) * sqrt(delta) * normals[j];
			interestRate[i][j] = std::max(interestRate[i][j], 0.0);
		}
		for (int j = 0; j <= numOfInterval; j++)
		{
			interestRate[i][j] = interestRate[i][j] + x;
		}
		delete[] normals;
	}
	delete g;
	return interestRate;
}

double discountC(double** ir, double C, int month, int numOfPaths)
{
	double delta = 1.0 / 12.0;
	
	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double sum = 0;
		for (int j = 0; j < month; j++)
			sum += ir[i][j];
		R[i] = sum * delta * (-1);
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]);
	res = res / (double)numOfPaths * C;
	delete[] R;
	return res;

}

double priceDiscountBondExplicitC(double FV, double** irtT, int t, double sigma, double Kappa, double ru, int numOfPaths)
{
	double h1 = sqrt(Kappa * Kappa + 2.0 * sigma * sigma);
	double h2 = (h1 + Kappa) / 2.0;
	double h3 = (2 * Kappa * ru) / (sigma * sigma);

	double duration = 10.0;
	double B = (exp(h1 * duration) - 1) / (h2 * (exp(h1 * duration) - 1) + h1);
	double temp = (h1 * exp(h2 * duration)) / (h2 * (exp(h1 * duration) - 1) + h1);
	double A = pow(temp, h3);

	double price = 0;
	for (int i = 0; i < numOfPaths; i++)
	{
		double rT = irtT[i][t];
		double p = A * exp(-B * rT) * FV;
		price += p;
	}
	price = price / (double)numOfPaths;
	return price;
}
*/
double priceMBS(int Years, double loanNotional, double WAC,
	double r0, double kappa, double r_bar, double sigma, int numOfPaths, double x)
{
	int numOfMonths = Years * 12;
	double R = WAC / 12.0;
	double* PV = new double[numOfMonths + 1];	PV[0] = loanNotional;
	double* C = new double[numOfMonths + 1];	C[0] = 0;

	double SY_month[12] = { 0.94,0.76,0.74,0.95,0.98,0.92,0.98,1.10,1.18,1.22,1.23,0.98 };
	double** ir_10 = simulateInterestRate(numOfPaths, r0, Years, sigma, kappa, r_bar, x);

	double res = 0;
	for (int i = 1; i <= numOfMonths; i++)
	{
		double MP = (PV[i - 1] * R) / (1.0 - pow(1 + R, -numOfMonths + (i - 1)));
		double SP = (PV[i - 1] * R) * ((1.0) / (1 - pow(1 + R, -numOfMonths + (i - 1))) -1 );

		// Calculate CPR
		/*
		double r_10 = 0; 
		int totald = (Years + 10) * 252;
		double dt = (Years + 10) / (double)totald;
		int days = 10 * 252;			
		int startDay = (i - 1)* 21 ;
		for (int m= 0; m < numOfPaths; m++)
		{
			double sum = 0;
			for (int j = startDay; j <= (startDay + days); j++)
				sum += ir_10[m][j];
			sum = sum * dt * (-1) / (double)(10*12*21);
			r_10 += sum;
		}
		r_10 = r_10 / (double)numOfPaths;
		*/
		double r_10 = -1 * log(priceDiscountBondExplicitC(1,ir_10,i-1,sigma,kappa,r_bar,numOfPaths)) / (double)(10);
				
		double Ri = 0.28 + 0.14 * atan(-8.57 + 430 * (R - r_10));
		double BU = 0.3 + 0.7 * (PV[i - 1] / PV[0]);
		double SG = std::min(1.0, (double)i / 30.0);
		double SY = SY_month[(i-1) % 12];
		double CPR = Ri * BU * SG * SY;
		double CPR_term = 1.0 - pow((1.0 - CPR), 1.0 / 12.0);

		double PP = (PV[i - 1] - SP) * CPR_term;
		C[i] = MP + PP; 
		PV[i] = PV[i - 1] - (SP + PP); 
		res += discountC(ir_10, C[i], i, numOfPaths);
	}
	for (int m = 0; m < numOfPaths; m++)
		delete[] ir_10[m];
	delete[] ir_10;

	delete[] PV;
	return res;
}

int main()
{
	// Mortgage
	double WAC = 0.08;
	int Years = 30;
	double loanNotional = 100000;
	// Interest Rate
	double r0 = 0.078;
	double kappa = 0.6;
	double r_bar = 0.08;
	double sigma_r = 0.12;
	int numOfPath = 10000;

	// Problem1
	std::cout << "Problem 1" << std::endl;
	std::cout << "(a) " ;
	std::cout << priceMBS(Years, loanNotional, WAC, r0, kappa, r_bar, sigma_r, numOfPath,0) << std::endl;
/*	*/
	std::cout << "(b) Changing K" << std::endl;
	for (double k = 0.3; k <= 0.9; k = k + 0.1)
		std::cout << priceMBS(Years, loanNotional, WAC, r0, k, r_bar, sigma_r, numOfPath,0) << ",";
	std::cout << std::endl;

	std::cout << "(c) Changing r_bar" << std::endl;
	for (double k = 0.03; k <= 0.09; k = k + 0.01)
		std::cout << priceMBS(Years, loanNotional, WAC, r0, kappa, k, sigma_r, numOfPath,0) << ",";
	std::cout << std::endl;

	std::cout << "(d) Changing sigma" << std::endl;
	for (double k = 0.10; k <= 0.20; k = k + 0.01)
		std::cout  << priceMBS(Years, loanNotional, WAC, r0, kappa, r_bar, k, numOfPath,0) << ",";
	std::cout << priceMBS(Years, loanNotional, WAC, r0, kappa, r_bar, 0.2, numOfPath, 0) << std::endl;
	

	

	std::cout << "Problem 2" << std::endl;
	double x = -0.0116;
	double pppp = priceMBS(Years, loanNotional, WAC, r0, kappa, r_bar, sigma_r, numOfPath, x);
	while (pppp < 110000)
	{
		x -= 0.00001;
		std::cout << pppp << std::endl;
		pppp = priceMBS(Years, loanNotional, WAC, r0, kappa, r_bar, sigma_r, numOfPath, x);
	}

	std::cout << pppp << " " << x << std::endl;

	std::cout << "Problem 3" << std::endl;
	double y = 0.0005;

	double p_plus = priceMBS(Years, loanNotional, WAC, r0, kappa, r_bar, sigma_r, numOfPath, x + y); std::cout << "P+ = " << p_plus;
	double p_minus = priceMBS(Years, loanNotional, WAC, r0, kappa, r_bar, sigma_r, numOfPath, x - y);std::cout << ", P- = " << p_plus << std::endl;
	double duration = (p_minus - p_plus) / (2.0 * y * pppp);
	double convexity = (p_plus + p_minus - 2.0 * pppp) / (2.0 * pppp * y * y);
	std::cout << "Duration is " << duration << ", and Convexity is " << convexity << std::endl;
}