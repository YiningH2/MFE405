
x = seq(0.3,0.9,by=0.1)
y = c(102347,101710,101108,100781,100702,100577,100321)
plot(x,y,main = "Question 1b - Changing K",type='l',xlab='k',ylab= 'Price')

x = seq(0.03,0.09,by=0.01)
y = c(137315,127969,120120,113013,106562,100729,95542.7)
plot(x,y,main = "Question 1c - Changing r_bar",type='l',xlab='r_bar',ylab= 'Price')

x = seq(0.1,0.2,by=0.01)
y = c(100658,100775,100884,101058,101232,101314,101378,101597,101557,101907,102111)
plot(x,y,main = "Question 1d - Changing sigma",type='l',xlab='sigma',ylab= 'Price')
