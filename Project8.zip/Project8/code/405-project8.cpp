// 405-project8.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Generater.h"

double** simulateInterestRate(int numOfPaths, int numOfInterval, double r0, double T, double sigma, double Kappa, double ru,int model)
{
	Generater* g = new Generater(2);
	double** interestRate = new double*[numOfPaths];
	//numOfInterval = T * 252;
	double delta = T / (double)numOfInterval;
	for (int i = 0; i < numOfPaths; i++)
	{
		interestRate[i] = new double[numOfInterval+1];
		double* normals = g->generateDefaultNormal(numOfInterval+1);
		interestRate[i][0] = r0;
		for (int j = 1; j <= numOfInterval; j++)
		{
			double rt = interestRate[i][j - 1];
			if (model == 0)
				interestRate[i][j] = rt + Kappa * (ru - rt) * delta + sigma * sqrt(delta) * normals[j];
			else if (model == 1)
				interestRate[i][j] = rt + Kappa * (ru - rt) * delta + sigma * sqrt(rt) * sqrt(delta) * normals[j];
			//if (interestRate[i][j] < 0) interestRate[i][j] = 0;
		}
		delete[] normals;
	}
	delete g;
	return interestRate;
}

double pricePureDiscountBond(double FV, double r0, double T, double t, double sigma, double Kappa, double ru, int numOfPaths, int numOfInterval, int model)
{
	double **ir = simulateInterestRate(numOfPaths, numOfInterval, r0, T - t, sigma, Kappa, ru, model);
	double delta = (T - t) / (double)numOfInterval;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double* currentIRPath = ir[i];
		double sum = 0;
		for (int j = 0; j <= numOfInterval; j++)
			sum += currentIRPath[j];
		R[i] = sum * delta * (-1);
		delete[] currentIRPath;
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]);
	res = res / (double)numOfPaths * FV;
	delete[] ir;
	delete[] R;
	return res;
}

double priceCouponBond(double FV, double C, double r0, double T, double t, double sigma, double Kappa, double ru, double * Ti,
	int numOfPaths, int numOfInterval)
{
	int numOfPayments = (int)(T - t) * 2;
	double* Ci = new double[numOfPayments];
	for (int i = 0; i < numOfPayments; i++)
		Ci[i] = C;
	Ci[numOfPayments - 1] += FV;

	double res = 0;
	for (int i = 0; i < numOfPayments; i++)
		res += pricePureDiscountBond(Ci[i], r0, Ti[i], t, sigma, Kappa, ru, numOfPaths, numOfInterval,0);

	delete[] Ci;
	return res;
}

// 1(c)
double priceCallOnPureDiscountBondExplicitV(double FV, double r0, double T, double S, double t, double sigma, double Kappa, double ru, double K,
	int numOfPaths, int numOfInterval)
{
	double B = (1 / Kappa) * (1 - exp(-Kappa * (S - T)));
	double A = exp((ru - sigma * sigma / (2 * Kappa * Kappa)) * (B - (S - T)) - sigma * sigma *B *B / (4 * Kappa));

	double** irtT = simulateInterestRate(numOfPaths, numOfInterval, r0, T - t, sigma, Kappa, ru, 0);
	double* payoff = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double rT = irtT[i][numOfInterval];
		double P = A * exp(-B * rT) * FV;
		payoff[i] = (P - K) > 0 ? (P - K) : 0;
	}

	double delta = (T - t) / (double)numOfInterval;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double sum = 0;
		for (int j = 0; j <= numOfInterval; j++)
			sum += irtT[i][j];
		R[i] = sum * delta * (-1);
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]) * payoff[i];
	res = res / (double)numOfPaths;

	for (int i = 0; i < numOfPaths; i++)
		delete[] irtT[i];
	delete[] R;
	delete[] irtT;
	delete[] payoff;
	return res;
}

// 1(d) 
double priceCallOnCouponBondV(double FV, double K, double C, double r0, double T, double S, double t, double sigma, double Kappa, double ru,
	double * Ti, int numOfPaths, int numOfInterval)
{
	int numOfPayments = (int)(S - T + 0.5) * 20 / 10;
	int totalPayments = (int)(S - t + 0.5) * 20 / 10;

	// Calculate all payments
	double* Ci = new double[numOfPayments];
	for (int i = 0; i < numOfPayments; i++)
		Ci[i] = C;
	Ci[numOfPayments - 1] += FV;

	// Simulate Interest Rate from t to T
	double** irtT = simulateInterestRate(numOfPaths, numOfInterval, r0, T - t, sigma, Kappa, ru, 0);
	double* rT = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
		rT[i] = irtT[i][numOfInterval];

	double* payoff = new double[numOfPaths];
	for (int m = 0; m < numOfPaths; m++)
	{
		double currentPrice = 0;
		for (int i = 0; i < numOfPayments; i++)
		{
			double p = pricePureDiscountBond(Ci[i], rT[m], Ti[i + (totalPayments - numOfPayments)], T, sigma, Kappa, ru, 1000, numOfInterval, 0);
			currentPrice += p;

		}			//std::cout << m << " ";
		currentPrice = (currentPrice - K) > 0 ? (currentPrice - K) : 0;
		payoff[m] = currentPrice;
	}

	double delta = (T - t) / (double)numOfInterval;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double sum = 0;
		for (int j = 0; j <= numOfInterval; j++)
			sum += irtT[i][j];
		R[i] = sum * delta * (-1);
	}

	double res_ = 0;
	for (int i = 0; i < numOfPaths; i++)
		res_ += exp(R[i]) * payoff[i];

	res_ = res_ / (double)numOfPaths;

	delete[] R;
	delete[] payoff;
	delete[] rT;

	for (int i = 0; i < numOfPaths; i++)
		delete[] irtT[i];
	delete[] irtT;
	delete[] Ci;
	return res_;
}

// 2(a)
double priceCallOnDiscountBondC(double FV, double K, double r0, double T, double S, double t, double sigma, double Kappa, double ru,
	 int numOfPaths, int numOfInterval)
{
	double** irtT = simulateInterestRate(numOfPaths, numOfInterval, r0, T - t, sigma, Kappa, ru, 1);
	double* payoff = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double rT = irtT[i][numOfInterval];
		double P = pricePureDiscountBond(FV, rT, S, T, sigma, Kappa, ru, 100, 100, 1);
		payoff[i] = (P - K) > 0 ? (P - K) : 0;
	}

	double delta = (T - t) / (double)numOfInterval;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double sum = 0;
		for (int j = 0; j <= numOfInterval; j++)
			sum += irtT[i][j];
		R[i] = sum * delta * (-1);
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]) * payoff[i];
	res = res / (double)numOfPaths;

	for (int i = 0; i < numOfPaths; i++)
		delete[] irtT[i];
	delete[] R;
	delete[] irtT;
	delete[] payoff;
	return res;
}

// 2(b)
double priceCallOnDiscountBondExplicitC(double FV, double K, double r0, double T, double S, double t, double sigma, double Kappa, double ru,
	int numOfPaths, int numOfInterval)
{
	double h1 = sqrt(Kappa * Kappa + 2 * sigma * sigma);
	double h2 = (h1 + Kappa) / 2.0;
	double h3 = (2 * Kappa * ru) / (sigma * sigma);

	double B = ( exp(h1 * (S - T)) - 1   ) / ( h2 * (exp(h1 * (S-T)) - 1) + h1 );
	double temp = (h1 * exp(h2 * (S-T))  ) / ( h2 * (exp(h1 * (S-T)) - 1) + h1 );
	double A = pow(temp, h3);

	double** irtT = simulateInterestRate(numOfPaths, numOfInterval, r0, T - t, sigma, Kappa, ru, 1);
	double* payoff = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double rT = irtT[i][numOfInterval];
		double P = A * exp(-B * rT) * FV;
		payoff[i] = (P - K) > 0 ? (P - K) : 0;
	}

	double delta = (T - t) / (double)numOfInterval;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double sum = 0;
		for (int j = 0; j <= numOfInterval; j++)
			sum += irtT[i][j];
		R[i] = sum * delta * (-1);
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]) * payoff[i];
	res = res / (double)numOfPaths;

	for (int i = 0; i < numOfPaths; i++)
		delete[] irtT[i];
	delete[] R;
	delete[] irtT;
	delete[] payoff;
	return res;
}

// 3
double** simulateG2InterestRate(int numOfPaths, int numOfInterval, 
	double x0, double y0, double phi0, double rou, double a, double b, double sigma, double nsig, 
	double r0, double T, double t)
{
	Generater* g = new Generater(2);
	double** interestRate = new double*[numOfPaths];

	double delta = (T-t) / (double)numOfInterval;
	for (int i = 0; i < numOfPaths; i++)
	{
		interestRate[i] = new double[numOfInterval + 3];
		double x = x0;
		double y = y0;
		double* normals = g->generateDefaultNormal(numOfInterval + 1);
		double* normals2 = g->generateDefaultNormal(numOfInterval + 1);
		interestRate[i][0] = phi0 + x + y;

		for (int j = 1; j <= numOfInterval; j++)
		{
			x = x - a * x * delta + sigma * sqrt(delta) * normals[j];
			y = y - b * y * delta + nsig * sqrt(delta) * (rou * normals[j] + sqrt(1-rou * rou) * normals2[j]);
			interestRate[i][j] = x + y + 0.03;
			//if (interestRate[i][j] < 0) interestRate[i][j] = 0;
		}

		interestRate[i][numOfInterval + 1] = x;
		interestRate[i][numOfInterval + 2] = y;
		delete[] normals;
		delete[] normals2;

	}
	delete g;
	return interestRate;
}


double pricePureDiscountBondG2(int numOfPaths, int numOfInterval, double FV, 
	double x0, double y0, double phi0, double rou, double a, double b, double sigma, double nsig,
	double r0, double T, double t)
{
	double **ir = simulateG2InterestRate(numOfPaths, numOfInterval, x0, y0, phi0, rou, a, b, sigma, nsig, r0, T,t);
	double delta = (T - t) / (double)numOfInterval;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double* currentIRPath = ir[i];
		double sum = 0;
		for (int j = 0; j <= numOfInterval; j++)
			sum += currentIRPath[j];
		R[i] = sum * delta * (-1);
		delete[] currentIRPath;
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]);
	res = res / (double)numOfPaths * FV;
	delete[] ir;
	delete[] R;
	return res;
}


double pricePutOnDiscountBondG(double FV, double K, double r0, double T, double S, double t,
	int numOfPaths, int numOfInterval)
{
	double** irtT = simulateG2InterestRate(numOfPaths, numOfInterval, 0,0,0.03,0.7,0.1,0.3,0.03,0.08,0.03,0.5,0);
	double* payoff = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double rT = irtT[i][numOfInterval];
		double P = pricePureDiscountBondG2(numOfPaths, numOfInterval, 1000,
			irtT[i][numOfInterval+1], irtT[i][numOfInterval+2], 0.03, 0.7, 0.1, 0.3, 0.03, 0.08, rT, S, T);
		payoff[i] = (K - P) > 0 ? (K - P) : 0;
		std::cout << i << " " << P << " ";
	}

	double delta = (T - t) / (double)numOfInterval;

	double* R = new double[numOfPaths];
	for (int i = 0; i < numOfPaths; i++)
	{
		double sum = 0;
		for (int j = 0; j <= numOfInterval; j++)
			sum += irtT[i][j];
		R[i] = sum * delta * (-1);
	}

	double res = 0;
	for (int i = 0; i < numOfPaths; i++)
		res += exp(R[i]) * payoff[i];
	res = res / (double)numOfPaths;

	for (int i = 0; i < numOfPaths; i++)
		delete[] irtT[i];
	delete[] R;
	delete[] irtT;
	delete[] payoff;
	return res;
}


int main()
{
	int path = 1000;
	int interval = 252;

	std::cout << "Problem 1:" << std::endl;
	std::cout << "1(a) ";
	//std::cout << pricePureDiscountBond(1000, 0.05, 0.5, 0, 0.18, 0.82, 0.05, path, interval,0) << std::endl;

	std::cout << "1(b) ";
	double Ti[8] = { 0.5,1,1.5,2,2.5,3,3.5,4 };
	std::cout << priceCouponBond(1000, 30, 0.05, 4, 0, 0.18, 0.82, 0.05, Ti, path, interval) << std::endl;

	std::cout << "1(c) ";
	//std::cout << priceCallOnPureDiscountBondExplicitV(1000, 0.05, 0.25, 0.5, 0, 0.18, 0.82, 0.05, 980, path, interval) << std::endl;

	std::cout << "1(d) ";
	//std::cout << priceCallOnCouponBondV(1000, 980, 30, 0.05, 0.25, 4, 0, 0.18, 0.82, 0.05, Ti, 1000, interval) << std::endl;

	std::cout << "Problem 2:" << std::endl;
	std::cout << "2(a) ";
	//std::cout << priceCallOnDiscountBondC(1000, 980, 0.05, 0.5, 1, 0, 0.18, 0.92, 0.055, 1000, interval) << std::endl;

	std::cout << "2(b) ";
	//std::cout << priceCallOnDiscountBondExplicitC(1000, 980, 0.05, 0.5, 1, 0, 0.18, 0.92, 0.055, path, interval) << std::endl;

	std::cout << "Problem 3:" << std::endl;
	std::cout << "3 ";
	std::cout << pricePutOnDiscountBondG(1000, 985, 0.03, 0.5, 1, 0,  1000, interval);

}

