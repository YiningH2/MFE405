﻿// 405-project3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#define _USE_MATH_DEFINES
#include "Generater.h"
#include <algorithm>
#include <vector>
#include <random>
#include <cstdlib>
#include <ctime>
#include <time.h>
#include <fstream>
#include <math.h> 
#include <iostream>

Generater* g = NULL;

// Function to appoximate N()
double approxN(double x)
{
	if (x < 0) {
		return (1 - approxN(x*(-1)));
	}
	double d[6] = { 0.0498673470,0.0211410061,0.0032776263,0.0000380036,0.0000488906,0.0000053830 };
	double sum = 1;
	for (int i = 0; i < 6; i++)
	{
		sum = sum + d[i] * pow(x, i + 1);
	}
	sum = pow(sum, -16.0) * 0.5;
	return 1 - sum;
}

// Function for 3(a) Price Euro Call by Monto Carlo
double priceCallMC(double S_0, double T, double X, double r, double sigma)
{
	int numOfSimulation = 10000;
	double* normals = g->generateNormals(numOfSimulation);
	double sum = 0;
	double sum2 = 0;
	for (int i = 0; i < numOfSimulation; i++)
	{
		double e = (r - sigma * sigma / 2.0) * (double)T + sigma * sqrt((double)T) * normals[i];
		double e2 = (r - sigma * sigma / 2.0) * (double)T + sigma * sqrt((double)T) * (-1) * normals[i];
		double S_T = S_0 * exp(e);
		double S_T_2 = S_0 * exp(e2);
		double payoff = S_T - X;
		double payoff2 = S_T_2 - X;
		if (payoff < 0) payoff = 0;
		if (payoff2 < 0) payoff2 = 0;
		sum = sum + payoff;
		sum2 = sum2 + payoff2;
	}
	delete[] normals;
	normals = NULL;
	double lhs = exp((-1) * r * T) / (double)numOfSimulation;
	return (lhs * sum + lhs * sum2) * 0.5;
}

// Function for 3(b) Price Euro Call by BS
double priceCallBS(double S_0, double T, double X, double r, double sigma)
{
	// c = S_0 * N(d1) - Xe^(-rT)N(d2)
	double d1 = (log(S_0 / X) + (r + sigma * sigma / 2) * T) / (sigma * sqrt(T));
	double d2 = d1 - sigma * sqrt(T);
	return S_0 * approxN(d1) - X * exp(-r * T) * approxN(d2);
}

// Function to handle negative value when taking power of 1/3
double cubicRoot(double x)
{
	int f = 1;
	if (x < 0)
	{
		x = x * (-1);
		f = -1;
	}	 
	return pow(x, (1.0 / 3)) * f;
}

double Halton_Seq(int index, int base) {
	double f = 1, r = 0;
	while (index > 0) {
		f = f / base;
		r = r + f * (index% base);
		index = index / base;
	}
	return r;
}

double* Halton_Seq_array(int index, int base) {
	double* res = new double[index];
	index = index + 1;
	int i = 0;
	double f = 1, r = 0;
	while (index > 0) {
		f = f / base;
		r = r + f * (index% base);
		index = index / base;
		res[i] = r;
		i++;
	}
	return res;
}

// Function to output data to a txt, given the filename, array and size
template <class T>
void outputFile(std::string filename, T arr[], int size)
{
	std::ofstream myfile(filename);
	if (myfile.is_open())
	{
		for (int count = 0; count < size; count++)
		{
			myfile << arr[count];
			if (count != (size - 1))
				myfile << "	";
		}
		myfile << '\n';
		myfile.close();
	}
}

void outputFile2D(std::string filename,  double *arr[100])
{
	std::ofstream myfile(filename);
	if (myfile.is_open())
	{
		for (int row = 0; row < 2; row++)
		{
			for (int col = 0; col < 100; col++)
			{
				myfile << arr[row][col];
				if (col != 99)
					myfile << "	";
			}
			myfile << '\n';

		}

		myfile.close();
	}
}

int main()
{
	// Initialize normal/uniform generator.
	// Note that the seed will be randomnized based on time inside the Generator's functions. 
	g = new Generater(123);

	// Problem 1
	std::cout << "Problem 1:" << std::endl;
	int numOfIntervals = 1000;
	int numOfSimulations = 1000;

	// P(Y_2 > 5)
	double delta_t = 2.0 / (double)numOfIntervals;
	int countIfLargerThanFive = 0;
	for (int j = 0; j < numOfSimulations; j++)
	{
		double y_T = 3.0 / (double) 4.0;
		double* normals = g->generateNormals(numOfIntervals);
		for (int i = 0; i < numOfIntervals; i++)
		{
			double y_last = y_T;
			double t = delta_t * (i + 1);
			double a = 2.0 / (1.0 + t) * y_last + (1 + t * t * t) / (double)3;
			double b = (1 + t * t * t) / (double)3;
			y_T = y_last + delta_t * (a) + sqrt(delta_t) * normals[i] * (b);
		}
		if (y_T > 5) countIfLargerThanFive++;
		delete[] normals;
		normals = NULL;
	}
	double Prob = countIfLargerThanFive / (double)numOfSimulations;
	std::cout << "Prob = " << Prob;
	
	// E[x_2^(1/3)]
	delta_t = 2.0 / (double)numOfIntervals;
	double sum = 0;
	for (int j = 0; j < numOfSimulations; j++)
	{
		double x_T = 1.0;
		double* normals = g->generateNormals(numOfIntervals);
		for (int i = 0; i < numOfIntervals; i++)
		{
			double x_last = x_T;
			double a = 0.2 - 0.5 * x_last;
			double b = 2.0 / 3.0;
			x_T = x_last + delta_t * a + sqrt(delta_t) * normals[i] * b;
		}
		sum = sum + cubicRoot(x_T);
		delete[] normals;
		normals = NULL;
	}
	double E1 = sum / (double)numOfSimulations;
	std::cout << ", E1 = " << E1;

	// E[y_3]
	delta_t = 3.0 / (double)numOfIntervals;
	sum = 0;
	for (int j = 0; j < numOfSimulations; j++)
	{
		double y_T = 3.0 / (double) 4.0;
		double* normals = g->generateNormals(numOfIntervals);
		for (int i = 0; i < numOfIntervals; i++)
		{
			double y_last = y_T;
			double t = delta_t * (i + 1);
			double a = 2.0 / (1.0 + t) * y_last + (1 + t * t * t) / 3.0;
			double b = (1 + t * t * t) / (double)3;
			y_T = y_last + delta_t * (a) + sqrt(delta_t) * normals[i] * (b);
		}
		sum = sum + y_T;
		delete[] normals;
		normals = NULL;
	}
	double E2 = sum / (double)numOfSimulations;
	std::cout << ", E2 = " << E2;

	// E[x_2*y_21(x_2>1)]
	delta_t = 2.0 / (double)numOfIntervals;
	sum = 0;
	for (int j = 0; j < numOfSimulations; j++)
	{
		double x_T = 1.0;
		double y_T = 3.0 / (double) 4.0;
		double* normalsx = g->generateNormals(numOfIntervals);
		double* normalsy = g->generateNormals(numOfIntervals);
		for (int i = 0; i < numOfIntervals; i++)
		{
			double x_last = x_T;
			double a = 0.2 - 0.5 * x_last;
			double b = 2.0 / 3.0;
			x_T = x_last + delta_t * a + sqrt(delta_t) * normalsx[i] * b;

			double y_last = y_T;
			double t = delta_t * (i + 1);
			a = 2.0 / (1.0 + t) * y_last + (1 + t * t * t) / (double)3;
			b = (1 + t * t * t) / (double)3;
			y_T = y_last + delta_t * (a)+sqrt(delta_t) * normalsy[i] * (b);
		}
		int f = 1;
		if (x_T <= 1)
		{
			f = 0;
		}
		sum = sum + x_T * y_T * f;
		delete[] normalsx;
		normalsx = NULL;
		delete[] normalsy;
		normalsy = NULL;
	}
	double E3 = sum / (double)numOfSimulations;
	std::cout << ", E3 = " << E3 << std::endl << std::endl;

	
	// Problem 2
	std::cout << "Problem 2:" << std::endl;

	// E(1 + x_3)^(1/3)
	delta_t = 3.0 / (double)numOfIntervals;
	sum = 0;
	for (int j = 0; j < numOfSimulations; j++)
	{
		double x_T = 1.0;
		double* normalsW = g->generateNormals(numOfIntervals);
		double* normalsZ = g->generateNormals(numOfIntervals);
		for (int i = 0; i < numOfIntervals; i++)
		{
			double x_last = x_T;
			double a = 0.25 * x_last;
			double b = 1.0 / 3.0 * x_last;
			double c = -3.0 / 4.0 * x_last;
			x_T = x_last + delta_t * a + sqrt(delta_t) * normalsW[i] * b + sqrt(delta_t) * normalsZ[i] * c;
		}
		sum = sum + cubicRoot(x_T+1);

		delete[] normalsW;
		normalsW = NULL;
		delete[] normalsZ;
		normalsZ = NULL;
	}
	E1 = sum / (double)numOfSimulations;
	std::cout << "E1 = " << E1;

	// E(1 + y_3)^(1/3)
	sum = 0;
	double* normalsW = g->generateNormals(numOfSimulations);
	double* normalsZ = g->generateNormals(numOfSimulations);
	for (int j = 0; j < numOfSimulations; j++)
	{
		double y_T = exp(-0.08*3.0 + 1.0/3.0 * sqrt(3.0)*normalsW[j] + 3.0 / 4.0 * sqrt(3.0)*normalsZ[j]);
		int f = 1;
		if (y_T < 0)
		{
			y_T = y_T * (-1);
			f = -1;
		}
		sum = sum + cubicRoot(y_T + 1);
	}

	E2 = sum / (double)numOfSimulations;
	std::cout << ", E2 = " << E2 << std::endl << std::endl;


	// Problem 3
	std::cout << "Problem 3:" << std::endl;
	double r = 0.04;
	double T = 0.5;
	double S_0 = 15;
	double X = 20;
	double sigma = 0.25;
	double C1 = priceCallMC(S_0, T, X, r, sigma);	//(88, 5, 100, 0.04, 0.2, g);
	double C2 = priceCallBS(S_0, T, X, r, sigma);
	double D[11] = {};
	double Theta[11] = {};
	double V[11] = {};
	double G[11] = {};
	double R[11] = {};

	for (int i = 15; i <= 25; i++)
	{
		double delta = 0.2;
		D[i - 15] = (priceCallMC(i+delta*i, T, X, r, sigma) - priceCallMC(i- delta * i, T, X, r, sigma)) / (2 * delta* i);
		Theta[i - 15] = (priceCallMC(i, T + delta * T, X, r, sigma) - priceCallMC(i, T - delta * T, X, r, sigma)) / (2 * delta * T);
		V[i - 15] = (priceCallMC(i, T, X, r, sigma + delta*sigma) - priceCallMC(i, T, X, r, sigma - delta * sigma)) / (2 * delta*sigma);
		double S_up = i + delta * i;
		double S_down = i - delta * i;
		double d_up = (priceCallMC(S_up + delta * S_up, T, X, r, sigma) - priceCallMC(S_up - delta * S_up, T, X, r, sigma)) / (2 * delta* S_up);
		double d_down = (priceCallMC(S_down + delta * S_down, T, X, r, sigma) - priceCallMC(S_down - delta * S_down, T, X, r, sigma)) / (2 * delta* S_down);
		G[i - 15] = (d_up - d_down) / (2 * delta * i);
		R[i - 15] = (priceCallMC(i, T, X, r + delta*r, sigma) - priceCallMC(i, T, X, r - delta * r, sigma )) / (2 * delta* r);
	}
	outputFile("D.txt", D, 11);
	outputFile("T.txt", Theta, 11);
	outputFile("V.txt", V, 11);
	outputFile("G.txt", G, 11);
	outputFile("R.txt", R, 11);

	std::cout << "C1 = " << C1;
	std::cout << ", C2 = " << C2 << std::endl << std::endl;


	// Problem 4
	std::cout << "Problem 4:" << std::endl;
	// Initialize variables
	double K = 50;
	double V_0 = 0.05;
	double alpha = 5.8;
	double beta = 0.0625;
	double cor = -0.6;
	T = 0.5;
	r = 0.03;
	S_0 = 48;
	sigma = 0.42;
	double delta = T / (double)numOfIntervals;
	
	double sum_ST_Full = 0;
	double sum_ST_Partial = 0;
	double sum_ST_Reflect = 0;
	for (int i = 0; i < numOfSimulations; i++)
	{
		double* V_Full_array = new double[numOfIntervals]; // Full Truncation
		double* V_Partial_array = new double[numOfIntervals]; // Partial Truncation
		double* V_Reflection_array = new double[numOfIntervals]; // Reflection

		double* normalsW1 = g->generateNormals(numOfIntervals);
		double* normalsW2 = g->generateNormals(numOfIntervals);

		double V_T_Full = V_0;
		double v_last_Full = V_T_Full;
		double V_T_Partial = V_0;
		double v_last_Partial = V_T_Partial;
		double V_T_Reflect = V_0;
		double v_last_Reflect = V_T_Reflect;
		for (int j = 0; j < numOfIntervals; j++)
		{
			// Full Truncation
			v_last_Full = V_T_Full;
			double d = alpha * (beta - (v_last_Full > 0 ? v_last_Full :0))*delta;
			double b = sigma * sqrt(v_last_Full > 0 ? v_last_Full : 0) * sqrt(delta) * (cor*normalsW1[j] + sqrt(1.0 - cor * cor)*normalsW2[j]);
			V_T_Full = v_last_Full + d + b;
			V_Full_array[j] = v_last_Full;

			// Partial Truncation
			v_last_Partial = V_T_Partial;
			d = alpha * (beta - v_last_Partial)*delta;
			b = sigma * sqrt(v_last_Partial > 0 ? v_last_Partial : 0) * sqrt(delta) * (cor*normalsW1[j] + sqrt(1.0 - cor * cor)*normalsW2[j]);
			V_T_Partial = v_last_Partial + d + b;
			V_Partial_array[j] = v_last_Partial;

			// Reflection
			v_last_Reflect = V_T_Reflect;
			d = alpha * (beta - abs(v_last_Reflect))*delta;
			b = sigma * sqrt(abs(v_last_Reflect)) * sqrt(delta) * (cor*normalsW1[j] + sqrt(1.0 - cor * cor)*normalsW2[j]);
			V_T_Reflect = abs(v_last_Reflect) + d + b;
			V_Reflection_array[j] = v_last_Reflect;
		}
		
		double S_T_Full = S_0 + r * S_0 * delta + sqrt(V_Full_array[0]) * S_0 * sqrt(delta) * normalsW1[0];
		double S_T_Partial = S_0 + r * S_0 * delta + sqrt(V_Partial_array[0]) * S_0 * sqrt(delta) * normalsW1[0];
		double S_T_Reflect = S_0 + r * S_0 * delta + sqrt(V_Reflection_array[0]) * S_0 * sqrt(delta) * normalsW1[0];

		double s_last_Full = S_T_Full;
		double s_last_Partial = S_T_Partial;
		double s_last_Reflect = S_T_Reflect;

		for (int j = 1; j < numOfIntervals; j++)
		{
			s_last_Full = S_T_Full;
			double d_s = r * s_last_Full * delta;
			double b_s = sqrt(V_Full_array[j]>0? V_Full_array[j]:0) * s_last_Full * sqrt(delta) * normalsW1[j];
			S_T_Full = s_last_Full + d_s + b_s;

			s_last_Partial = S_T_Partial;
			d_s = r * s_last_Partial * delta;
			b_s = sqrt(V_Full_array[j] > 0 ? V_Full_array[j] : 0) * s_last_Partial * sqrt(delta) * normalsW1[j];
			S_T_Partial = s_last_Partial + d_s + b_s;

			s_last_Reflect = S_T_Reflect;
			d_s = r * s_last_Reflect * delta;
			b_s = sqrt(abs(V_Reflection_array[j])) * s_last_Reflect * sqrt(delta) * normalsW1[j];
			S_T_Reflect = s_last_Reflect + d_s + b_s;
		}

		double payoff = (S_T_Full - K) > 0 ? (S_T_Full - K) : 0;
		sum_ST_Full = sum_ST_Full + payoff;
		payoff = (S_T_Partial - K) > 0 ? (S_T_Partial - K) : 0;
		sum_ST_Partial = sum_ST_Partial + payoff;
		payoff = (S_T_Reflect - K) > 0 ? (S_T_Reflect - K) : 0;
		sum_ST_Reflect = sum_ST_Reflect + payoff;

		delete[] V_Full_array;
		V_Full_array = NULL;
		delete[] V_Partial_array;
		V_Partial_array = NULL;
		delete[] V_Reflection_array;
		V_Reflection_array = NULL;
		delete[] normalsW1;
		normalsW1 = NULL;
		delete[] normalsW2;
		normalsW2 = NULL;
	}

	double lhs = exp((-1) * r * T) / (double)numOfSimulations;
	C1 = lhs * sum_ST_Full;
	C2 = lhs * sum_ST_Partial;
	double C3 = lhs * sum_ST_Reflect;
	std::cout << "C1 = " << C1;
	std::cout << ", C2 = " << C2;
	std::cout << ", C3 = " << C3 << std::endl << std::endl;


	// Problem 5
	std::cout << "Problem 5:" << std::endl;
	// (a)
	double** uniform2D_a = new double*[2];
	for (int i = 0; i < 2; i++)
	{
		uniform2D_a[i] = g->generateUniforms(100);
	}

	// (b)
	double** Halton2D_b = new double*[2];
	Halton2D_b[0] = new double[100];
	Halton2D_b[1] = new double[100];
	for (int i = 1; i <= 100; i++)
	{
		Halton2D_b[0][i-1] = Halton_Seq(i, 2);
		Halton2D_b[1][i-1] = Halton_Seq(i, 7);
	}

	// (c)
	double** Halton2D_c = new double*[2];
	Halton2D_c[0] = new double[100];
	Halton2D_c[1] = new double[100];
	for (int i = 1; i <= 100; i++)
	{
		Halton2D_c[0][i-1] = Halton_Seq(i, 2);
		Halton2D_c[1][i-1] = Halton_Seq(i, 4);
	}

	outputFile2D("5a.txt", uniform2D_a);
	outputFile2D("5b.txt", Halton2D_b);
	outputFile2D("5c.txt", Halton2D_c);


	// (e)
	int N = 10000;
	int pairs[3][2] =
	{
		{2,4},
		{2,7},
		{5,7}
	};
	for (int p = 0; p < 3; p++)
	{
		double** Halton2D_e = new double*[2];
		Halton2D_e[0] = new double[N];
		Halton2D_e[1] = new double[N];
		int base1 = pairs[p][0];
		int base2 = pairs[p][1];
		for (int i = 1; i <= N; i++)
		{
			Halton2D_e[0][i - 1] = Halton_Seq(i, base1);
			Halton2D_e[1][i - 1] = Halton_Seq(i, base2);
		}
		double I = 0;
		for (int i = 0; i < N; i++)
		{
			double x = Halton2D_e[0][i];
			double y = Halton2D_e[1][i];
			double t = exp((-1)* x * y) * (sin(6 * M_PI * x) + cubicRoot(cos(2 * M_PI * y)));
			I = I + t;
		}

		std::cout << "I = " << I / N << " for base " << base1 << " and " << base2 <<std::endl;
	}
	

	delete[] uniform2D_a;
	uniform2D_a = NULL;
	delete[] Halton2D_b;
	Halton2D_b = NULL;
	delete[] Halton2D_c;
	Halton2D_c = NULL;
}

