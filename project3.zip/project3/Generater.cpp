#include "Generater.h"
#include <math.h> 
#include <ctime>
#include <cstdlib>

Generater::Generater(int x)
{
	seed = x;
}


Generater::~Generater()
{
}

void Generater::setRandomSeed()
{
	srand(time(0));
	seed = seed + rand();
}

double* Generater::generateUniforms(int size)
{
	setRandomSeed();
	long long a = (long long)pow(7, 5);
	long long m = (long long)pow(2, 31) - 1;

	long long* nums = new long long[size]; // an array to store all values calculated
	nums[0] = (a * seed) % m;
	for (int i = 1; i < size; i++)
	{
		nums[i] = (a * nums[i - 1]) % m;       
	}

	double* uniformNums = new double[size];
	for (int i = 0; i < size; i++)
	{
		// Divide by m to get the Uniforms btw 0 and 1
		uniformNums[i] = (double)nums[i] / (double)m;
	}
	// Clean the data
	delete[] nums;
	nums = NULL;
	return uniformNums;
}

double* Generater::generateNormals(int size)
{
	double* uniform_1 = generateUniforms(size*2);
	double* uniform_2 = generateUniforms(size*2);
	double* normal_PM = new double[size];
	int counter = 0;
	int i = 0;
	while (counter < size)
	{
		double U1 = uniform_1[i];
		double U2 = uniform_2[i];
		double V1 = 2 * U1 - 1;
		double V2 = 2 * U2 - 1;
		double W = V1 * V1 + V2 * V2;
		if (W < 1)
		{
			double Z1 = V1 * sqrt((-2.0 * log(W)) / W);
			double Z2 = V2 * sqrt((-2.0 * log(W)) / W);
			normal_PM[counter] = Z1;
			normal_PM[counter + 1] = Z2;
			counter = counter + 2;
		}
		i++;
	}

	delete[]uniform_1;
	uniform_1 = NULL;
	delete[]uniform_2;
	uniform_2 = NULL;
	return normal_PM;
}



double Generater::calculateMean(double nums[], int total)
{
	// Function to calculate the mean of an array, given the size
	double mean = 0;
	for (int i = 0; i < total; i++)
	{
		mean = mean + nums[i];
	}
	mean = mean / total;
	return mean;
}

double Generater::calculateSD(double nums[], int total, double mean)
{
	// Function to calculate the sd of an array, given the size and mean
	double sd = 0;
	for (int i = 0; i < total; i++)
	{
		sd = sd + (nums[i] - mean) * (nums[i] - mean);
	}
	sd = sqrt(sd / total);
	return sd;
}

double Generater::cov(double x[], double y[], int total)
{
	double c = 0;
	double x_mean = calculateMean(x, total);
	double y_mean = calculateMean(y, total);
	for (int i = 0; i < total; i++)
	{
		c = c + (x[i] - x_mean) * (y[i] - y_mean);
	}
	c = c / double(total);
	return c;
}