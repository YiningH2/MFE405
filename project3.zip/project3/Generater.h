#pragma once

class Generater
{
public:
	Generater(int x);
	~Generater();
	
	double* generateUniforms(int size);
	double* generateNormals(int size);

	double calculateMean(double nums[], int total);
	double calculateSD(double nums[], int total, double mean);

	double cov(double x[], double y[], int total);
	int seed = 0;

private:
	void setRandomSeed();
};

