
x = seq(15,25,by = 1)
data = read.delim("D.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - Delta",type='l',xlab='S0')

data = read.delim("T.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - Theta",type='l',xlab='S0')

data = read.delim("V.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - Vega",type='l',xlab='S0')

data = read.delim("G.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - Gamma",type='l',xlab='S0')

data = read.delim("R.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - Rho",type='l',xlab='S0')

par(mfrow=c(1,1))

data = read.delim("5a.txt",header = FALSE, dec = ".")
data = t(data)
plot(data,main = "Question 5a - Uniform")

data = read.delim("5b.txt",header = FALSE, dec = ".")
data = t(data)
plot(data,main = "Question 5b - Halton(base 2 and 7)")

data = read.delim("5c.txt",header = FALSE, dec = ".")
data = t(data)
plot(data,main = "Question 5c - Halton(base 2 and 4)")
