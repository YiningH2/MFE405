// 405-project4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <fstream>
#include <iostream>
#include <sstream>
#include "Generater.h"

double priceBinomialTree(double u, double d, double p_up, double S0, double K, double r, double T, int n)
{
	double delta = T / (double)n;
	// build the all prices for the binomial tree
	double** prices = new double*[n+1];
	for (int i = 0; i < n + 1; i++)
	{
		prices[i] = new double[i + 1];
		for (int j = 0; j <= i; j++)
		{
			prices[i][j] = S0 * pow(u,j) * pow(d,i-j);
		}
	}

	double** payoffs = new double*[n + 1];
	payoffs[n] = new double[n + 1];
	for (int i = 0; i < n + 1; i++)
	{
		double p = prices[n][i] - K;
		if (p < 0) p = 0;
		payoffs[n][i] = p;
	}
	for (int i = n-1; i >= 0; i--)
	{
		payoffs[i] = new double[i + 1];
		for (int j = 0; j < i + 1; j++)
		{
			double up_expected = p_up * payoffs[i+1][j+1];
			double down_expected = (1-p_up) * payoffs[i + 1][j];
			payoffs[i][j] = exp(-r * delta) * (up_expected + down_expected);
		}
	}
	double res = payoffs[0][0];
	// Free up memory
	for (int i = 0; i < n + 1; i++) {
		delete[] prices[i];
		delete[] payoffs[i];
	}
	delete[] prices; 
	delete[] payoffs;
	return res;
}

double priceBinomialTreeModel(double S0, double K, double r, double T, double sigma, int n,int type)
{
	 // Type 0 for Call, type 1 for Put
	double delta = T / (double)n;
	double c = 0.5 * (exp(-1 * r * delta) + exp((r + sigma * sigma) * delta));
	double d = c - sqrt(c * c - 1);
	double u = 1.0 / d;
	double p_up = (exp(r * delta) - d) / (u - d);

	// build the all prices for the binomial tree
	double** prices = new double*[n + 1];
	for (int i = 0; i < n + 1; i++)
	{
		prices[i] = new double[i + 1];
		for (int j = 0; j <= i; j++)
		{
			prices[i][j] = S0 * pow(u, j) * pow(d, i - j);
		}
	}

	double** payoffs = new double*[n + 1];
	payoffs[n] = new double[n + 1];
	for (int i = 0; i < n + 1; i++)
	{
		double p;
		if (type == 0)
			p = prices[n][i] - K;
		else p = K - prices[n][i];
		
		if (p < 0) p = 0;
		payoffs[n][i] = p;
	}
	for (int i = n - 1; i >= 0; i--)
	{
		payoffs[i] = new double[i + 1];
		for (int j = 0; j < i + 1; j++)
		{
			double up_expected = p_up * payoffs[i + 1][j + 1];
			double down_expected = (1 - p_up) * payoffs[i + 1][j];
			payoffs[i][j] = exp(-r * delta) * (up_expected + down_expected);
		}
	}
	double res = payoffs[0][0];
	// Free up memory
	for (int i = 0; i < n + 1; i++) {
		delete[] prices[i];
		delete[] payoffs[i];
	}
	delete[] prices;
	delete[] payoffs;
	return res;
}

double priceBinomialTreeModelAmerican(double S0, double K, double r, double T, double sigma, int n, int type)
{
	// Type 0 for Call, type 1 for Put
	double delta = T / (double)n;
	double c = 0.5 * (exp(-1 * r * delta) + exp((r + sigma * sigma) * delta));
	double d = c - sqrt(c * c - 1);
	double u = 1.0 / d;
	double p_up = (exp(r * delta) - d) / (u - d);

	// build the all prices for the binomial tree
	double** prices = new double*[n + 1];
	for (int i = 0; i < n + 1; i++)
	{
		prices[i] = new double[i + 1];
		for (int j = 0; j <= i; j++)
		{
			prices[i][j] = S0 * pow(u, j) * pow(d, i - j);
		}
	}

	double** payoffs = new double*[n + 1];
	payoffs[n] = new double[n + 1];
	for (int i = 0; i < n + 1; i++)
	{
		double p;
		if (type == 0) // if Call
			p = prices[n][i] - K;
		else p = K - prices[n][i]; // if Put
		if (p < 0) p = 0;
		payoffs[n][i] = p;
	}
	for (int i = n - 1; i >= 0; i--)
	{
		payoffs[i] = new double[i + 1];
		for (int j = 0; j < i + 1; j++)
		{
			double up_expected = p_up * payoffs[i + 1][j + 1];
			double down_expected = (1 - p_up) * payoffs[i + 1][j];
			double CV = exp(-r * delta) * (up_expected + down_expected);
			double p;
			if (type == 0) // if Call
				p = prices[i][j] - K;
			else p = K - prices[i][j]; // if Put
			if (p < 0) p = 0;
			payoffs[i][j] = CV > p ? CV : p;	
		}
	}
	double res = payoffs[0][0];
	// Free up memory
	for (int i = 0; i < n + 1; i++) {
		delete[] prices[i];
		delete[] payoffs[i];
	}
	delete[] prices;
	delete[] payoffs;
	return res;
}

double priceTriomialTree(double u, double d, double p_up, double p_down,  double S0, double K, double r, double T, int n, int type)
{
	// Type 0 for normal, type 1 for log-tree
	if (type == 1) S0 = log(S0);
	double delta = T / (double)n;
	double p_m = 1 - p_up - p_down;
	// build the all prices for the binomial tree
	double** prices = new double*[n + 1];
	for (int i = 0; i < n + 1; i++)
	{
		prices[i] = new double[1 + i * 2];
		for (int j = 0; j <= i * 2; j++)
		{
			int mid = j / 2;
			if (j == mid) 
			{
				prices[i][j] = type == 0? S0:exp(S0);
			}
			else if (j < mid)
			{
				if (type == 0)
					prices[i][j] = S0 * pow(d, i - j);
				else 
					prices[i][j] = exp(S0 + d * (i - j));
			} else 
			{
				if (type == 0)
					prices[i][j] = S0 * pow(u, j-i);
				else 
					prices[i][j] = exp(S0 + u * (j - i));
			}
			
		}
	}

	double** payoffs = new double*[n + 1];
	payoffs[n] = new double[1 + n * 2];
	for (int i = 0; i < 1 + n * 2; i++)
	{
		double p = prices[n][i] - K;
		if (p < 0) p = 0;
		payoffs[n][i] = p;
	}
	for (int i = n - 1; i >= 0; i--)
	{
		payoffs[i] = new double[1 + i * 2];
		for (int j = 0; j < 1 + i * 2; j++)
		{
			double up_expected = p_up * payoffs[i + 1][j + 2];
			double down_expected = p_down * payoffs[i + 1][j];
			double m_expected = p_m * payoffs[i + 1][j+1];
			payoffs[i][j] = exp(-r * delta) * (up_expected + down_expected + m_expected);
		}
	}
	double res = payoffs[0][0];
	// Free up memory
	for (int i = 0; i < n + 1; i++) {
		delete[] prices[i];
		delete[] payoffs[i];
	}
	delete[] prices;
	delete[] payoffs;
	return res;
}

double priceCallHalton(double S0, double K, double T, double r, double sigma, int n, int base1, int base2)
{
	Generater g(0);
	// Generate normals
	double* normals = g.generateBoxMullerNormals(n, base1, base2);
	double sum = 0;
	for (int i = 0; i < n; i++)
	{
		double price = S0 * exp((r - sigma * sigma * 0.5) * T + (sigma * sqrt(T) * normals[i]));
		double payoff = price - K;
		if (payoff < 0) payoff = 0;
		sum += payoff;
	}
	return sum * exp(-r * T) / (double)n;

}

// Function to output data to a txt, given the filename, array and size
template <class T>
void outputFile(std::string filename, T arr[], int size)
{
	std::ofstream myfile(filename);
	if (myfile.is_open())
	{
		for (int count = 0; count < size; count++)
		{
			myfile << arr[count];
			if (count != (size - 1))
				myfile << "	";
		}
		myfile << '\n';
		myfile.close();
	}
}

int main()
{
	// Problem 1
	std::cout << "Problem 1:" << std::endl;
	double r = 0.05;
	double T = 0.5;
	double sigma = 0.24;
	double S0 = 32;
	double K = 30;
	int nIntervals[7] = { 10,20,40,80,100,200,500 };
	double u, d, p, delta;

	// (a)
	std::cout << "(a) ";
	double res[7] = {};
	for (int i = 0; i < 7; i++)
	{
		int n = nIntervals[i];
		delta = T / (double)n;
		double c = 0.5 * (exp(-1 * r * delta) + exp((r + sigma * sigma) * delta));
		d = c - sqrt(c * c - 1);
		u = 1.0 / d;
		p = (exp(r * delta) - d) / (u - d);

		res[i] = priceBinomialTree(u, d, p, S0, K, r, T, n);
		std::cout << res[i] << " ";
	}
	outputFile("1a.txt", res, 7);

	// (b)
	std::cout << std::endl << "(b) ";
	for (int i = 0; i < 7; i++)
	{
		int n = nIntervals[i];
		delta = T / (double)n;
		d = exp(r*delta)*(1 - sqrt(exp(sigma*sigma*delta) - 1));
		u = exp(r*delta)*(1 + sqrt(exp(sigma*sigma*delta) - 1));
		p = 0.5;
		res[i] = priceBinomialTree(u, d, p, S0, K, r, T, n);
		std::cout << res[i] << " ";
	}
	outputFile("1b.txt", res, 7);

	// (c)
	std::cout << std::endl << "(c) ";
	for (int i = 0; i < 7; i++)
	{
		int n = nIntervals[i];
		delta = T / (double)n;
		d = exp((r - sigma * sigma / 2)*delta - sigma * sqrt(delta));
		u = exp((r - sigma * sigma / 2)*delta + sigma * sqrt(delta));
		p = 0.5;
		res[i] = priceBinomialTree(u, d, p, S0, K, r, T, n);
		std::cout << res[i] << " ";
	}
	outputFile("1c.txt", res, 7);

	// (d)
	std::cout << std::endl << "(d) ";
	for (int i = 0; i < 7; i++)
	{
		int n = nIntervals[i];
		delta = T / (double)n;
		u = exp(sigma * sqrt(delta));
		d = exp(-1 * sigma * sqrt(delta));
		p = 0.5 + 0.5 * ((r - sigma * sigma*0.5)*sqrt(delta) / sigma);
		res[i] = priceBinomialTree(u, d, p, S0, K, r, T, n);
		std::cout << res[i] << " ";
	}
	outputFile("1d.txt", res, 7);


	// Problem 2
	std::cout << std::endl << std::endl << "Problem 2:" << std::endl;
	r = 0.02;
	T = 0.95;
	S0 = 1151.87;
	K = int(S0*1.1) / 10 * 10;
	int n = 500;
	delta = T / (double)n;

	// Read in CSV and calculate volatility
	std::ifstream infile("GOOGL.csv");
	std::string lines[1259] = {};
	double prices[1258] = {};
	std::string line;
	int l = 0;
	while (getline(infile, line, '\n'))
	{
		if (l < 1259)
			lines[l] = line;
		l++;
	}
	for (int i = 1; i < 1259; ++i) {
		std::size_t pos = lines[i].find(",");      // position of the end of the name of each one in the respective string
		prices[i - 1] = std::stod(lines[i].substr(pos + 1, lines[i].size())); // convert string age to a double
	}
	double price_change[1257] = {};
	for (int i = 1; i < 1257; ++i) {
		double percent = (prices[i] - prices[i - 1]) / prices[i - 1];
		price_change[i - 1] = percent;
	}

	Generater g(0);
	double mean = g.calculateMean(price_change, 1257);
	sigma = g.calculateSD(price_change, 1257, mean) * sqrt(252);// -0.01102;
	std::cout << sigma << std::endl;

	double c = 0.5 * (exp(-1 * r * delta) + exp((r + sigma * sigma) * delta));
	d = c - sqrt(c * c - 1);
	u = 1.0 / d;
	p = (exp(r * delta) - d) / (u - d);
	double priceQ2 = priceBinomialTree(u, d, p, S0, K, r, T, n);
	std::cout << priceQ2 << std::endl;
	// the GOOGL200117C01260000	2019-02-05 9:38AM EST	1,260.00  of 66.30	at 2/6/2019 2 am
	// where the closest value for sima is 0.222389


	// Problem 3
	std::cout << std::endl << "Problem 3:" << std::endl;
	S0 = 49;
	K = 50;
	r = 0.03;
	sigma = 0.2;
	T = 0.3846;

	n = 300;
	delta = T / (double)n;

	// (i) Delta, function of S0, 20-80 increment of 2
	double delta_Price[31] = {};
	for (int i = 0; i <= 30; i ++)
	{
		S0 = 20 + i * 2;
		double epi = 0.1;
		delta_Price[i] = (priceBinomialTreeModel(S0 + epi * S0,K,r,T,sigma,n,0) - priceBinomialTreeModel(S0 - epi * S0, K, r, T, sigma, n, 0)) / (2 * epi* S0);
	}
	outputFile("3i.txt", delta_Price, 31);

	// (ii) Delta, function of T, 0 - 0.3846 increment of 0.01
	S0 = 49;
	double delta_T[38] = {};
	for (int i = 0; i <= 37; i++)
	{
		T = 0.01 + i * 0.01;
		double epi = 0.01;
		delta_T[i] = (priceBinomialTreeModel(S0, K, r, T + T * epi, sigma, n, 0) - priceBinomialTreeModel(S0, K, r, T - T * epi, sigma, n, 0)) / (2 * epi* T);
	}
	outputFile("3ii.txt", delta_T, 38);

	T = 0.3846;
	double theta_Price[31] = {};
	double gamma_Price[31] = {};
	double vega_Price[31] = {};
	double rho_Price[31] = {};
	for (int i = 0; i <= 30; i++)
	{
		S0 = 20 + i * 2;
		double epi = 0.1;
		theta_Price[i] = (priceBinomialTreeModel(S0, K, r, T + T * epi, sigma, n, 0) - priceBinomialTreeModel(S0, K, r, T - T * epi, sigma, n, 0)) / (2 * epi* T);
		double S_up = S0 + epi * S0;
		double S_down = S0 - epi * S0;
		double d_up = (priceBinomialTreeModel(S_up + epi * S_up, K, r, T, sigma, n, 0) - priceBinomialTreeModel(S_up - epi * S_up, K, r, T, sigma, n, 0)) / (2 * epi * S_up);
		double d_down = (priceBinomialTreeModel(S_down + epi * S_down, K, r, T, sigma, n, 0) - priceBinomialTreeModel(S_down - epi * S_down, K, r, T, sigma, n, 0)) / (2 * epi * S_down);
		gamma_Price[i] = (d_up - d_down) / (2 * epi * S0);
		vega_Price[i] = (priceBinomialTreeModel(S0, K, r, T, sigma + sigma * epi, n, 0) - priceBinomialTreeModel(S0, K, r, T, sigma - sigma * epi, n, 0)) / (2 * epi* sigma);
		rho_Price[i] = (priceBinomialTreeModel(S0, K, r + r * epi, T, sigma, n, 0) - priceBinomialTreeModel(S0, K, r - r * epi, T, sigma, n, 0)) / (2 * epi* r);
	}
	outputFile("3iii.txt", theta_Price, 31);
	outputFile("3iv.txt", gamma_Price, 31);
	outputFile("3v.txt", vega_Price, 31);
	outputFile("3vi.txt", rho_Price, 31);

	// Problem 4
	std::cout << std::endl << "Problem 4:" << std::endl;

	sigma = 0.3;
	r = 0.05;
	K = 100;
	T = 1;

	double priceEuropean[11] = {};
	double priceAmerican[11] = {};
	for (int i = 0; i <= 10; i ++)
	{
		double S = 80 + i * 4;
		priceEuropean[i] = priceBinomialTreeModel(S, K, r, T, sigma, n, 1);
		priceAmerican[i] = priceBinomialTreeModelAmerican(S, K, r, T, sigma, n, 1);
	}
	outputFile("4E.txt", priceEuropean, 11);
	outputFile("4A.txt", priceAmerican, 11);

	// Problem 5
	std::cout << std::endl << "Problem 5:" << std::endl;
	r = 0.05;
	sigma = 0.24;
	T = 0.5;
	S0 = 32;
	K = 30;
	int nIntervalsQ5[9] = { 10,15,20,40,70,80,100,200,500 };

	// (a)
	std::cout << "(a) ";
	double resQ5[9] = {};
	for (int i = 0; i < 9; i++)
	{
		int n_Q5 = nIntervalsQ5[i];
		delta = T / (double)n_Q5;
		d = exp(-sigma * sqrt(3 * delta));
		u = 1 / d;
		double p_d = (r * delta * (1 - u) + (r*delta)*(r*delta) + sigma * sigma*delta) / ((u - d)*(1 - d));
		double p_u = (r * delta * (1 - d) + (r*delta)*(r*delta) + sigma * sigma*delta) / ((u - d)*(u - 1));
		resQ5[i] = priceTriomialTree(u, d, p_u, p_d, S0, K, r, T, n_Q5,0);
		std::cout << resQ5[i] << " ";
	}
	outputFile("5a.txt", resQ5, 9);

	// (a)
	std::cout << std::endl << "(b) ";
	double resQ5_2[9] = {};
	for (int i = 0; i < 9; i++)
	{
		int n_Q5 = nIntervalsQ5[i];
		delta = T / (double)n_Q5;
		u = sigma * sqrt(3 * delta);
		d = -sigma * sqrt(3 * delta);
		double temp = (sigma * sigma * delta + (r - sigma * sigma * 0.5) * (r - sigma * sigma * 0.5) * delta* delta) / (u * u);
		double temp2 = (r - sigma * sigma * 0.5) * delta / u;
		double p_d = 0.5*(temp - temp2);
		double p_u = 0.5 * (temp + temp2);
		resQ5_2[i] = priceTriomialTree(u, d, p_u, p_d, S0, K, r, T, n_Q5,1);
		std::cout << resQ5_2[i] << " ";
	}
	outputFile("5b.txt", resQ5_2, 9);


	// Problem 6
	std::cout << std::endl << "Problem 6:" << std::endl;
	std::cout << "Please input S0, K, T, r, sigma, N, base 1 and base 2: ";
	int base1, base2;
	std::cin >> S0 >> K >> T >> r >> sigma >> n >> base1 >> base2;
	double C = priceCallHalton(S0, K, T, r, sigma, n, base1, base2);
	std::cout << "The Price is : " << std::endl << C;

	//32 30 0.5 0.05 0.24 1000 2 3
	//The Price is :
	//3.71216
}




