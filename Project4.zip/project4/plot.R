par(mfrow=c(2,2))
x = c(10,20,40,80,100,200,500)

data = read.delim("1a.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 1 - a",type='l',xlab='n',ylab='price')

data = read.delim("1b.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 1 - b",type='l',xlab='n',ylab='price')

data = read.delim("1c.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 1 - c",type='l',xlab='n',ylab='price')

data = read.delim("1d.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 1 - d",type='l',xlab='n',ylab='price')




par(mfrow=c(3,2))
x = seq(20,80,by=2)
data = read.delim("3i.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - i Delta to Price",type='l',xlab='Price')

x = seq(0.01,0.38,by=0.01)
data = read.delim("3ii.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - ii Delta to T",type='l',xlab='T')

x = seq(20,80,by=2)
data = read.delim("3iii.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - iii Theta to Price",type='l',xlab='Price')

data = read.delim("3iv.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - iv Gamma to Price",type='l',xlab='Price')

data = read.delim("3v.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - v Vega to Price",type='l',xlab='Price')

data = read.delim("3vi.txt",header = FALSE, dec = ".")
data = t(data)
plot(x,data,main = "Question 3 - vi Rho to Price",type='l',xlab='Price')


par(mfrow=c(1,1))
x = seq(80,120,by=4)
data = read.delim("4E.txt",header = FALSE, dec = ".")
data = t(data)
data2 = read.delim("4A.txt",header = FALSE, dec = ".")
data2 = t(data2)
plot(x,data,main = "Question 4",type='l',xlab='Stock Price',ylab="Put Price",col = "red")
lines(x,data2,col = "blue")


x = c(10, 15, 20, 40, 70, 80, 100, 200, 500 )
data = read.delim("5a.txt",header = FALSE, dec = ".")
data = t(data)
data2 = read.delim("5b.txt",header = FALSE, dec = ".")
data2 = t(data2)
plot(x,data,main = "Question 5",type='l',xlab='N',ylab="Call Price",col = "red")
lines(x,data2,col = "blue")



