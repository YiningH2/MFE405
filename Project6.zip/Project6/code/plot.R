par(mfrow=c(2,1))
x = seq(0.12,0.48,by=0.04)
y = c( 9.01136, 12.3931, 15.3723, 18.5438, 22.0227, 25.7444, 30.044, 34.4035, 38.6227, 42.0424)
#data = read.delim("1a.txt",header = FALSE, dec = ".")
#data = t(data)
plot(x,y,main = "Question 1 - Lookback Call",type='l',xlab='Sigma',ylab= 'Price')

y = c(9.10836, 11.8706, 14.4924, 17.0196, 19.4984, 21.8906, 24.1256, 26.4702, 28.7876, 31.0763)

#data = read.delim("1b.txt",header = FALSE, dec = ".")
#data = t(data)
plot(x,y,main = "Question 1 - Lookback Put",type='l',xlab='Sigma',ylab= 'Price')

count = 0
for (i in 1:1000)
{
  if (test[i] == 99) 
    count = count + 1;
}

x_axis = c(3,4,5,6,7,8)
# Fix Lambda 1, for different L2, Plot 3 plots vs times
F1C2_0_value = c(2985.51,2988.82,2994.96,2997.01,3001.33,3004.48)
F1C2_0_prob = c(1,1,1,1,1,1)
F1C2_0_time = c(0.003,0.004,0.005,0.006,0.007,0.008)

F1C2_0.1_value = c(2882.42,3674.47,4270.15,4806.86,5261.03,5576.31)
F1C2_0.1_prob = c(0.4822,0.63555,0.74895,0.83415,0.8908,0.9292)
F1C2_0.1_time = c(0.9683,1.16891,1.31089,1.43704,1.49848,1.53674)

F1C2_0.2_value = c(3495.56,4162.03,4617.61,4997.44,5346.03,5578.77)
F1C2_0.2_prob = c(0.6257,0.7621,0.85525,0.9128,0.9562,0.9718)
F1C2_0.2_time = c(1.01193,1.18078,1.29076,1.33201,1.38589,1.39263)

F1C2_0.3_value = c(3875.52,4410.79,4765.19,5049.02,5249.11,5492.9)
F1C2_0.3_prob = c(0.72925,0.8494,0.9173,0.95685,0.97655,0.9886)
F1C2_0.3_time = c(1.00205,1.14273,1.21806,1.24507,1.22662,1.22025)

F1C2_0.4_value = c(4070.01,4410.36,4712.48,4982.4,5203.91,5369.63)
F1C2_0.4_prob = c(0.7974,0.8997,0.95315,0.97845,0.99055,0.9962)
F1C2_0.4_time = c(0.95344,1.05931,1.10777,1.12601,1.10109,1.09946)

F1C2_0.5_value = c(4151.56,4409.07,4672.15,4874.11,5104.66,5226.04)
F1C2_0.5_prob = c(0.8563,0.9364,0.9736,0.9901,0.99515,0.99815)
F1C2_0.5_time = c(0.901809,1.00238,1.02316,1.01846,0.989235,0.974347)

F1C2_0.6_value = c(4138.35,4341.76,4590.16,4805.25,4993.34,5176.94)
F1C2_0.6_prob = c(0.8938,0.95645,0.98485,0.9944,0.99785,0.99935)
F1C2_0.6_time = c(0.877827,0.932399,0.934753,0.915483,0.899275,0.88791)

F1C2_0.7_value = c(4071.57,4277.3,4519.69,4729.19,4926.22,5117.87)
F1C2_0.7_prob = c(0.9226,0.974,0.99005,0.99665,0.9993,0.99965)
F1C2_0.7_time = c(0.816517,0.865318,0.852124,0.837213,0.813874,0.79597)

F1C2_0.8_value = c(4042.99,4201.17,4459.23,4643.94,4870.58,4991.29)
F1C2_0.8_prob = c(0.9422,0.98245,0.995,0.9988,0.99955,1)
F1C2_0.8_time = c(0.784738,0.802667,0.785072,0.768243,0.746466,0.739286)



# Fix Lambda 2, for different L1, Plot 3 plots vs times
F2C1_0.05_value = c(3610.81,3865.88,4149.11,4311.09,4509.43,4627.42)
F2C1_0.05_prob = c(0.74765,0.86485,0.9307,0.9598,0.9825,0.9899)
F2C1_0.05_time = c(1.07169,1.19383,1.26963,1.28325,1.28675,1.27264)

F2C1_0.1_value = c(3768.67,4072.58,4325.1,4529.24,4718.54,4895.36)
F2C1_0.1_prob = c(0.76715,0.87485,0.93745,0.97075,0.9858,0.99335)
F2C1_0.1_time = c(1.03071,1.15927,1.22602,1.2388,1.23088,1.21188)

F2C1_0.15_value = c(3892.53,4273.14,4555.95,4782.5,5019.97,5192.67)
F2C1_0.15_prob = c(0.7838,0.8939,0.9485,0.97555,0.9887,0.99505)
F2C1_0.15_time = c(0.978963,1.11239,1.17094,1.16702,1.17291,1.14602)

F2C1_0.2_value = c(4020.86,4394.05,4728.91,4960.99,5220.6,5396.16)
F2C1_0.2_prob = c(0.7989,0.8992,0.9526,0.978,0.9917,0.99505)
F2C1_0.2_time = c(0.945722,1.07329,1.10755,1.12393,1.11922,1.07561)

F2C1_0.25_value = c(4187.48,4586.13,4919.7,5180.84,5403.85,5576.43)
F2C1_0.25_prob = c(0.8134,0.9097,0.95745,0.983,0.99155,0.9968)
F2C1_0.25_time = c(0.925942,1.03303,1.07171,1.07281,1.06447,1.04641)

F2C1_0.3_value = c(4300.93,4739.81,5140.33,5384.21,5587.6,5766.1)
F2C1_0.3_prob = c(0.82645,0.918,0.9651,0.9847,0.9939,0.99675)
F2C1_0.3_time = c(0.896321,0.99722,1.04273,1.02923,1.00873,0.993528)

F2C1_0.35_value = c(4438.96,4937.19,5287.45,5593.05,5819.58,5949.13)
F2C1_0.35_prob = c(0.8436,0.92705,0.9695,0.98805,0.9943,0.9973)
F2C1_0.35_time = c(0.871553,0.950685,0.988833,0.986806,0.973121,0.957151)

F2C1_0.4_value = c(4575.12,5055.57,5438.48,5727.42,5965.01,6137.84)
F2C1_0.4_prob = c(0.8541,0.93655,0.97455,0.9911,0.99595,0.99895)
F2C1_0.4_time = c(0.834354,0.914921,0.956346,0.938994,0.939201,0.918199)



par(mfrow=c(3,2))



plot(x_axis,F1C2_0_value,type='l',main='Fixing L1, Changing L2 - Values',col =1,ylim=c(2500,6000),ylab='Value')
lines(x_axis,F1C2_0.1_value,col =2)
lines(x_axis,F1C2_0.2_value,col =3)
lines(x_axis,F1C2_0.3_value,col =4)
lines(x_axis,F1C2_0.4_value,col =5)
lines(x_axis,F1C2_0.5_value,col =6)
lines(x_axis,F1C2_0.6_value,col =7)
lines(x_axis,F1C2_0.7_value,col =8)
lines(x_axis,F1C2_0.8_value,col =9)

plot(x_axis,F2C1_0.05_value,type='l',main='Fixing L2, Changing L1 - Values',col =1,ylim=c(2500,6000),ylab='Value')
lines(x_axis,F2C1_0.1_value,col =2)
lines(x_axis,F2C1_0.15_value,col =3)
lines(x_axis,F2C1_0.2_value,col =4)
lines(x_axis,F2C1_0.25_value,col =5)
lines(x_axis,F2C1_0.3_value,col =6)
lines(x_axis,F2C1_0.35_value,col =7)
lines(x_axis,F2C1_0.4_value,col =8)


plot(x_axis,F1C2_0_prob,type='l',main='Fixing L1, Changing L2 - Probability',col =1,ylim=c(0.2,1.2),ylab='Prob')
lines(x_axis,F1C2_0.1_prob,col =2)
lines(x_axis,F1C2_0.2_prob,col =3)
lines(x_axis,F1C2_0.3_prob,col =4)
lines(x_axis,F1C2_0.4_prob,col =5)
lines(x_axis,F1C2_0.5_prob,col =6)
lines(x_axis,F1C2_0.6_prob,col =7)
lines(x_axis,F1C2_0.7_prob,col =8)
lines(x_axis,F1C2_0.8_prob,col =9)

plot(x_axis,F2C1_0.05_prob,type='l',main='Fixing L2, Changing L1 - Probability',col =1,ylim=c(0.6,1.1),ylab='Prob')
lines(x_axis,F2C1_0.1_prob,col =2)
lines(x_axis,F2C1_0.15_prob,col =3)
lines(x_axis,F2C1_0.2_prob,col =4)
lines(x_axis,F2C1_0.25_prob,col =5)
lines(x_axis,F2C1_0.3_prob,col =6)
lines(x_axis,F2C1_0.35_prob,col =7)
lines(x_axis,F2C1_0.4_prob,col =8)

plot(x_axis,F1C2_0_time,type='l',main='Fixing L1, Changing L2 - Expected Exercise Times',col =1,ylim=c(0.5,1.5),ylab='Time')
lines(x_axis,F1C2_0.1_time,col =2)
lines(x_axis,F1C2_0.2_time,col =3)
lines(x_axis,F1C2_0.3_time,col =4)
lines(x_axis,F1C2_0.4_time,col =5)
lines(x_axis,F1C2_0.5_time,col =6)
lines(x_axis,F1C2_0.6_time,col =7)
lines(x_axis,F1C2_0.7_time,col =8)
lines(x_axis,F1C2_0.8_time,col =9)


plot(x_axis,F2C1_0.05_time,type='l',main='Fixing L2, Changing L1 - Expected Exercise Times',col =1,ylim=c(0.5,1.5),ylab='Time')
lines(x_axis,F2C1_0.1_time,col =2)
lines(x_axis,F2C1_0.15_time,col =3)
lines(x_axis,F2C1_0.2_time,col =4)
lines(x_axis,F2C1_0.25_time,col =5)
lines(x_axis,F2C1_0.3_time,col =6)
lines(x_axis,F2C1_0.35_time,col =7)
lines(x_axis,F2C1_0.4_time,col =8)
      
      
##########################################################





x_axis = c(3,4,5,6,7,8)
# Fix Lambda 1, for different L2, Plot 3 plots vs times
F1C2_0_value = c(2989.54,2986.45,2993.35,2997.95,3002.91,3009.71)
F1C2_0_prob = c(1,1,1,1,1,1)
F1C2_0_time = c(0.003,0.004,0.005,0.006,0.007,0.008)

F1C2_0.1_value = c(2869.89,3661.18,4274.41,4818.18,5194.44,5590.26)
F1C2_0.1_prob = c(0.4833,0.6363,0.74655,0.8339,0.88635,0.93315)
F1C2_0.1_time = c(0.964107,1.15741,1.31652,1.43668,1.50755,1.54036)

F1C2_0.2_value = c(3437.61,4108.86,4662.59,5054.86,5337.88,5547.86)
F1C2_0.2_prob = c(0.6217,0.7571,0.8569,0.91595,0.9515,0.97065)
F1C2_0.2_time = c(1.00385,1.17587,1.27599,1.35149,1.39181,1.40572)

F1C2_0.3_value = c(3864.86,4350.39,4702.56,5030.96,5297.05,5448.67)
F1C2_0.3_prob = c(0.7289,0.84825,0.91425,0.9554,0.97875,0.9882)
F1C2_0.3_time = c(0.992153,1.13601,1.20442,1.2404,1.25671,1.24227)

F1C2_0.4_value = c(4066.05,4389.12,4709.64,4981.53,5170.46,5351.92)
F1C2_0.4_prob = c(0.799,0.9015,0.9515,0.9781,0.991,0.996)
F1C2_0.4_time = c(0.956336,1.07524,1.11462,1.12578,1.11924,1.08732)

F1C2_0.5_value = c(4143.3,4411.46,4686.04,4881.07,5076.55,5268.54)
F1C2_0.5_prob = c(0.8552,0.93455,0.97255,0.9881,0.99505,0.9989)
F1C2_0.5_time = c(0.924253,1.00464,1.01641,1.0158,0.991524,0.974752)

F1C2_0.6_value = c(4139.63,4377.38,4624.69,4786.32,4997.06,5173.73)
F1C2_0.6_prob = c(0.89565,0.96025,0.987,0.9933,0.99785,0.9997)
F1C2_0.6_time = c(0.860481,0.926339,0.926205,0.904979,0.900967,0.871762)

F1C2_0.7_value = c(4090.89,4306.56,4523.82,4719.11,4923.11,5052.94)
F1C2_0.7_prob = c(0.9263,0.9737,0.99115,0.99735,0.99905,0.9999)
F1C2_0.7_time = c(0.812558,0.858585,0.856878,0.840758,0.814951,0.800222)

F1C2_0.8_value = c(4033.57,4225.35,4446.25,4681.4,4805.06,5004.61)
F1C2_0.8_prob = c(0.94335,0.9807,0.9937,0.99835,0.99965,1)
F1C2_0.8_time = c(0.774537,0.799382,0.800395,0.768102,0.748162,0.735514)



# Fix Lambda 2, for different L1, Plot 3 plots vs times
F2C1_0.05_value = c(3631.89,3857.98,4100.35,4327.54,4453.45,4658.27)
F2C1_0.05_prob = c(0.75535,0.8603,0.92585,0.9656,0.9825,0.9908)
F2C1_0.05_time = c(1.06681,1.2139,1.2805,1.29691,1.29011,1.27939)

F2C1_0.1_value = c(3723.21,4039.41,4291.81,4562.95,4729.92,4879.79)
F2C1_0.1_prob = c(0.7699,0.87275,0.9371,0.9692,0.9851,0.9936)
F2C1_0.1_time = c(1.01781,1.14557,1.22088,1.2212,1.22561,1.19639)

F2C1_0.15_value = c(3854.71,4239.15,4512.32,4747.6,4964.32,5127.52)
F2C1_0.15_prob = c(0.78125,0.88495,0.94475,0.97465,0.9883,0.9951)
F2C1_0.15_time = c(0.987506,1.11182,1.16408,1.15861,1.17445,1.15002)

F2C1_0.2_value = c(4105.65,4390.06,4716.75,4991.35,5207.24,5368.75)
F2C1_0.2_prob = c(0.7994,0.90125,0.9534,0.9796,0.98925,0.99545)
F2C1_0.2_time = c(0.968271,1.05203,1.11472,1.12479,1.10898,1.09109)

F2C1_0.25_value = c(4181.19,4591.55,4904.08,5186.59,5426.81,5586.3)
F2C1_0.25_prob = c(0.8117,0.91465,0.95705,0.98265,0.99255,0.99665)
F2C1_0.25_time = c(0.928485,1.02429,1.07187,1.07808,1.06242,1.04094)

F2C1_0.3_value = c(4305.59,4759.94,5082.9,5385.73,5588.81,5817.49)
F2C1_0.3_prob = c(0.8265,0.9177,0.96315,0.98665,0.9942,0.9983)
F2C1_0.3_time = c(0.895951,0.989025,1.01615,1.03592,1.01474,0.983742)

F2C1_0.35_value = c(4478.02,4936.11,5247.79,5570.23,5796.15,5992.02)
F2C1_0.35_prob = c(0.8435,0.9291,0.9684,0.98895,0.99545,0.9976)
F2C1_0.35_time = c(0.873377,0.959996,0.987356,0.979859,0.976409,0.945753)

F2C1_0.4_value = c(4611.52,5094.02,5451.57,5706.98,5980.65,6206.29)
F2C1_0.4_prob = c(0.85695,0.9371,0.9733,0.98815,0.9964,0.9983)
F2C1_0.4_time = c(0.841933,0.918951,0.941357,0.945433,0.920542,0.897717)



par(mfrow=c(3,2))



plot(x_axis,F1C2_0_value,type='l',main='Fixing L1, Changing L2 - Values',col =1,ylim=c(2500,6000),ylab='Value')
lines(x_axis,F1C2_0.1_value,col =2)
lines(x_axis,F1C2_0.2_value,col =3)
lines(x_axis,F1C2_0.3_value,col =4)
lines(x_axis,F1C2_0.4_value,col =5)
lines(x_axis,F1C2_0.5_value,col =6)
lines(x_axis,F1C2_0.6_value,col =7)
lines(x_axis,F1C2_0.7_value,col =8)
lines(x_axis,F1C2_0.8_value,col =9)

plot(x_axis,F2C1_0.05_value,type='l',main='Fixing L2, Changing L1 - Values',col =1,ylim=c(2500,6000),ylab='Value')
lines(x_axis,F2C1_0.1_value,col =2)
lines(x_axis,F2C1_0.15_value,col =3)
lines(x_axis,F2C1_0.2_value,col =4)
lines(x_axis,F2C1_0.25_value,col =5)
lines(x_axis,F2C1_0.3_value,col =6)
lines(x_axis,F2C1_0.35_value,col =7)
lines(x_axis,F2C1_0.4_value,col =8)


plot(x_axis,F1C2_0_prob,type='l',main='Fixing L1, Changing L2 - Probability',col =1,ylim=c(0.2,1.2),ylab='Prob')
lines(x_axis,F1C2_0.1_prob,col =2)
lines(x_axis,F1C2_0.2_prob,col =3)
lines(x_axis,F1C2_0.3_prob,col =4)
lines(x_axis,F1C2_0.4_prob,col =5)
lines(x_axis,F1C2_0.5_prob,col =6)
lines(x_axis,F1C2_0.6_prob,col =7)
lines(x_axis,F1C2_0.7_prob,col =8)
lines(x_axis,F1C2_0.8_prob,col =9)

plot(x_axis,F2C1_0.05_prob,type='l',main='Fixing L2, Changing L1 - Probability',col =1,ylim=c(0.6,1.1),ylab='Prob')
lines(x_axis,F2C1_0.1_prob,col =2)
lines(x_axis,F2C1_0.15_prob,col =3)
lines(x_axis,F2C1_0.2_prob,col =4)
lines(x_axis,F2C1_0.25_prob,col =5)
lines(x_axis,F2C1_0.3_prob,col =6)
lines(x_axis,F2C1_0.35_prob,col =7)
lines(x_axis,F2C1_0.4_prob,col =8)

plot(x_axis,F1C2_0_time,type='l',main='Fixing L1, Changing L2 - Expected Exercise Times',col =1,ylim=c(0.5,1.5),ylab='Time')
lines(x_axis,F1C2_0.1_time,col =2)
lines(x_axis,F1C2_0.2_time,col =3)
lines(x_axis,F1C2_0.3_time,col =4)
lines(x_axis,F1C2_0.4_time,col =5)
lines(x_axis,F1C2_0.5_time,col =6)
lines(x_axis,F1C2_0.6_time,col =7)
lines(x_axis,F1C2_0.7_time,col =8)
lines(x_axis,F1C2_0.8_time,col =9)


plot(x_axis,F2C1_0.05_time,type='l',main='Fixing L2, Changing L1 - Expected Exercise Times',col =1,ylim=c(0.5,1.5),ylab='Time')
lines(x_axis,F2C1_0.1_time,col =2)
lines(x_axis,F2C1_0.15_time,col =3)
lines(x_axis,F2C1_0.2_time,col =4)
lines(x_axis,F2C1_0.25_time,col =5)
lines(x_axis,F2C1_0.3_time,col =6)
lines(x_axis,F2C1_0.35_time,col =7)
lines(x_axis,F2C1_0.4_time,col =8)
  
  
