// 405-project6.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <fstream>
#include <iostream>
#include "Generater.h"
#include <algorithm>
#include <vector>
#include <queue>
#include <string>


double priceLookback(double S0, double r, double sigma, double T, double K, int type, Generater* g)
{
	int numOfPaths = 10000;
	int numOfInterval = 200;
	double delta = T / (double)numOfInterval;
	double discountFactor = exp(-1 * r * T) / (double)numOfPaths;

	double sum = 0;

	for (int i = 0; i < numOfPaths/2; i ++)
	{
		double* normals = g->generateDefaultNormal(numOfInterval);
		double minMaxPrice_1 = S0;
		double minMaxPrice_2 = S0;
		double last_S_1 = S0;
		double last_S_2 = S0;

		for (int j = 0; j < numOfInterval; j ++)
		{
			double St_1_1 = last_S_1 + r * delta * last_S_1 + sigma * last_S_1 * sqrt(delta) * normals[j];
			double St_1_2 = last_S_2 + r * delta * last_S_2 - sigma * last_S_2 * sqrt(delta) * normals[j];
			last_S_1 = St_1_1;
			last_S_2 = St_1_2;
			if (type == 0)	// if call, get MAX
			{
				if (St_1_1 > minMaxPrice_1) minMaxPrice_1 = St_1_1;
				if (St_1_2 > minMaxPrice_2) minMaxPrice_2 = St_1_2;
			}
			else  // if put, get MIN
			{
				if (St_1_1 < minMaxPrice_1) minMaxPrice_1 = St_1_1;
				if (St_1_2 < minMaxPrice_2) minMaxPrice_2 = St_1_2;
			}
		}
		double payoff_1 = type == 0 ? minMaxPrice_1 - K : K - minMaxPrice_1;
		double payoff_2 = type == 0 ? minMaxPrice_2 - K : K - minMaxPrice_2;
		if (payoff_1 < 0) payoff_1 = 0;
		if (payoff_2 < 0) payoff_2 = 0;
		//std::cout << minMaxPrice_1 << " ";
		sum = sum + payoff_1 + payoff_2;
		delete[] normals;
		normals = NULL;
	}

	return sum * discountFactor;
}

// Function to output data to a txt, given the filename, array and size
template <class T>
void outputFile(std::string filename, T arr[], int size)
{
	std::ofstream myfile(filename);
	if (myfile.is_open())
	{
		for (int count = 0; count < size; count++)
		{
			myfile << arr[count];
			if (count != (size - 1))
				myfile << ",";
		}
		//myfile << '\n';
		myfile.close();
	}
}

double round(double var)
{
	double value = (int)(var * 1000 + .5);
	return (double)value / 1000;
}

double* valueDefaultOption(double lambda_1, double lambda_2, double T,Generater* g)
{

	double V0 = 20000;
	double L0 = 22000;

	double mu = -0.1;
	double sigma = 0.2;
	double gamma = -0.4;

	double r_0 = 0.02;

	double delta = 0.25;
	double alpha = 0.7;
	double epi = 0.95;
	double beta = (epi - alpha) / (double)T;

	double R = r_0 + delta * lambda_2;
	double r = R / 12.0;
	int n = T * 12;
	double PMT = (L0 * r) / (1 - ( 1 / pow(1 + r, n) ) );
	double a = PMT / r;
	double b = PMT / (r * pow(1 + r, n));
	double c = 1 + r;

	int numOfPaths = 20000;
	int numOfInterval = 1000;
	int defaultCount = 0;
	double dt = T / (double)numOfInterval;

	double sum = 0;
	double time = 0;
	double* expos_2 = g->generateExponential(numOfPaths, lambda_2);

	for (int i = 0; i < numOfPaths; i++)
	{
		// Generate all jump times
		std::queue<double> jump_times;
		//std::vector<double> jump_times;
		double jump_sum = 0;
		while (jump_sum < T)
		{
			double* expos_1 = g->generateExponential(numOfInterval, lambda_1);
			int jump_index = 0;
			while (jump_index < numOfInterval)
			{
				if (jump_sum > T) 
					break;
				double time = round(expos_1[jump_index]);
				jump_times.push(jump_sum + time);
				jump_sum += time;
				jump_index++;
			}

			delete[] expos_1;
		}
		
		double* normals = g->generateDefaultNormal(numOfInterval);
	
		double event_time = round(expos_2[i]);
		double Vt = V0;
		double Q_time = T + 1;
		double S_time = T + 1;
		double payoff;
		for (int j = 0; j < numOfInterval; j++)
		{
			double t = dt * (j + 1);
			double Vt1 = Vt + mu * Vt * dt + sigma * sqrt(dt) * Vt * normals[j];
			if (jump_times.size() != 0)
			{
				if (t > jump_times.front())
				{
					Vt1 = Vt1 * (1 + gamma);
					jump_times.pop();
				}
			}
			
			Vt = Vt1;

			double Lt = a - b * pow(c, 12 * t);
			double qt = alpha + beta * t;
			double threshold = qt * Lt;
			
			if (t >= event_time)
			{
				payoff = abs(Lt - epi * Vt);
				S_time = t;
				break;
			}
			else 
			if (Vt <= threshold) 
			{
				payoff = (Lt - epi * Vt) > 0 ? (Lt - epi * Vt) : 0;
				Q_time = t;
				break;
			}
		}

		double tau = std::min(Q_time, S_time);
		if (tau < T)
		{
			sum += payoff * pow(exp(-r_0), tau);
			defaultCount++;
			time += tau;
		}
		delete[] normals;
	}
	delete[] expos_2;
	
	std::cout << "For Lambda 1 = " << lambda_1 << ", Lambda 2 = " << lambda_2 << " and T = " << T << std::endl;
	std::cout << "	Value is " << sum / (double)numOfPaths << std::endl;
	std::cout << "	Default Prob is " << (double)defaultCount / (double)numOfPaths << std::endl;
	std::cout << "	Expected excercise time is " << (double)time/ (double)defaultCount << std::endl << std::endl;

	double res[3] = { sum / (double)numOfPaths ,(double)defaultCount / (double)numOfPaths ,(double)time / (double)defaultCount };
	return res;
}


int main()
{
	Generater* g = new Generater(2);

	// Problem 1
	/*	*/
	std::cout << "Problem 1: " << std::endl;
	std::cout << "Call prices for different sigma: ";
	double p[10] = {};
	for (double sigma = 0.12; sigma <= 0.48; sigma += 0.04)
	{
		double price = priceLookback(98, 0.03, sigma, 1.0, 100, 0, g);
		int i = (sigma - 0.12) / 0.04; p[i] = price;
		std::cout << p[i] << ", ";
	}
	outputFile("1a.txt", p, 10);

	std::cout << std::endl << "Put prices for different sigma: ";
	for (double sigma = 0.12; sigma <= 0.48; sigma += 0.04)
	{
		double price = priceLookback(98, 0.03, sigma, 1.0, 100, 1, g);
		int i = (sigma - 0.12) / 0.04; p[i] = price;
		std::cout << p[i] << ", ";
	}
	outputFile("1b.txt", p, 10);

	std::cout << std::endl << "Problem 2: ";
	
	//valueDefaultOption(0.2, 0.4, 5, g);
		
	std::cout << "Fixing lambda 1, Change L2: " << std::endl;
	double lambda_1 = 0.2;
	double values[6] = {};
	double prob[6] = {};
	double time[6] = {};
	
	for (double lambda_2 = 0.0; lambda_2 <= 0.8; lambda_2 += 0.1)
	{
		for (double T = 3; T <= 8; T ++)
		{
			double* res = valueDefaultOption(lambda_1, lambda_2, T, g);
			values[(int)T - 3] = res[0];
			prob[(int)T - 3] = res[1];
			time[(int)T - 3] = res[2];
		}
		outputFile("L1" + std::to_string(lambda_1) + "L2" + std::to_string(lambda_2) + "values.txt", values, 6);
		outputFile("L1" + std::to_string(lambda_1) + "L2" + std::to_string(lambda_2) + "prob.txt", prob, 6);
		outputFile("L1" + std::to_string(lambda_1) + "L2" + std::to_string(lambda_2) + "times.txt", time, 6);
	}
	



	std::cout << "Fixing lambda 2, Change L1: " << std::endl;
	double lambda_2 = 0.4;
	for (double lambda_1 = 0.05; lambda_1 <= 0.4; lambda_1 += 0.05)
	{
		for (double T = 3; T <= 8; T++)
		{
			double* res = valueDefaultOption(lambda_1, lambda_2, T, g);
			values[(int)T - 3] = res[0];
			prob[(int)T - 3] = res[1];
			time[(int)T - 3] = res[2];
		}
		outputFile("L2" + std::to_string(lambda_2) + "L1" + std::to_string(lambda_1) + "values.txt", values, 6);
		outputFile("L2" + std::to_string(lambda_2) + "L1" + std::to_string(lambda_1) +  "prob.txt", prob, 6);
		outputFile("L2" + std::to_string(lambda_2) + "L1" + std::to_string(lambda_1) +  "times.txt", time, 6);
	}
	/**/

	delete g;
	return 0;
}
