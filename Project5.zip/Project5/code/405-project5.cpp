// 405-project5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <Eigen/Dense>
#include "Generater.h"
#include <vector>
#include "Matrix.h"

using Eigen::MatrixXd;

// To calculate Laguerre polynomials 0
double Laguerre(double x, int k)
{
	double k1 = exp(-x / 2.0);
	if (k == 1)
		return k1;
	else if (k == 2)
		return k1 * (1.0-x) ;
	else if (k == 3)
		return k1 * (1.0 - 2.0 * x + x * x / 2.0) ;
	return k1 * (1.0 - 3.0 * x + 3.0 * x * x / 2.0 - x * x * x / 6.0);
}

// To calculate Hermite polynomials 1 
double Hermite(double x, int k)
{
	double k1 = 1;
	if (k == 1)
		return k1;
	else if (k == 2)
		return 2.0*x;
	else if (k == 3)
		return 4.0 * x * x - 2.0;
	return 8 * x * x * x - 12 * x;
}

// To calculate Monomials polynomials 2 
double Monomials(double x, int k)
{
	double k1 = 1;
	if (k == 1)
		return k1;
	else if (k == 2)
		return x;
	else if (k == 3)
		return x * x ;
	return x * x * x;
}

double BasisFunction(int type, double x, int k)
{
	if (type == 0)
	{
		return Laguerre(x, k);
	}
	else if (type == 1)
	{
		return Hermite(x, k);
	}
	return Monomials(x, k);
	
}

double priceLSMC(double S0, double r, double sigma, double T, double K, 
	int kTerm, int basisType, Generater* g)
{
	int numOfPaths = 10000;
	int numOfInterval = 200;
	double delta = T / (double)numOfInterval;

	int* ind = new int[numOfPaths];	// indexes
	double* expectedPayoffs = new double[numOfPaths];	// expected payoffs look up table

	// Generate the entire path matrix
	double** priceM = new double*[numOfPaths];
	//MatrixXd priceM(numOfPaths, numOfInterval);
	
	for (int i = 0; i < numOfPaths; i ++)
	{
		priceM[i] = new double[numOfInterval];
		//priceM[i+1] = new double[numOfInterval];
		double* normals = g->generateDefaultNormal(numOfInterval);
		for (int j = 0; j < numOfInterval; j++)
		{
			double St = S0 / S0;
			if (j != 0)
				St = priceM[i][j - 1];
			priceM[i][j] = St + r * delta * St + sigma * St * sqrt(delta) * normals[j];
			//priceM[i + 1][j] = St + r * delta * St - sigma * St * sqrt(delta) * normals[j];
		}
		delete[] normals;
		normals = NULL;
	}


	// Calculate payoff for Tn when n = numOfInterval 
	for (int i = 0; i < numOfPaths; i++)
	{
		ind[i] = -1;
		expectedPayoffs[i] = 0;
		double payoff = K/S0 - priceM[i][numOfInterval - 1];
		if (payoff > 0)
		{
			ind[i] = numOfInterval - 1;
			expectedPayoffs[i] = payoff;
		}

	}

	// For Tn when n is btw n and 0
	for (int j = numOfInterval - 2; j >= 0; j--)
	{
		int* inTheMoneyRowIndex = new int[numOfPaths];
		int numOfInTheMoney = 0;
		for (int i = 0; i < numOfPaths; i++)
		{
			double payoff = K/S0 - priceM[i][j];// Calculate EV
			if (payoff > 0)
			{
				inTheMoneyRowIndex[numOfInTheMoney] = i;
				numOfInTheMoney++;
			}
		}

		if (numOfInTheMoney != 0)
		{
			// Construct f matrixes
			MatrixXd* fMatrixes = new MatrixXd[kTerm];
			for (int k = 0; k < kTerm; k++)
			{
				MatrixXd f(1, numOfInTheMoney);
				for (int i = 0; i < numOfInTheMoney; i++)
				{
					f(0, i) = BasisFunction(basisType, priceM[inTheMoneyRowIndex[i]][j], k + 1);
				}
				fMatrixes[k] = f;
			}

			// Construct A matrix
			MatrixXd A(kTerm, kTerm);
			for (int row = 0; row < kTerm; row++)
			{
				for (int col = 0; col < kTerm; col++)
				{
					A(row, col) = (fMatrixes[col] * (fMatrixes[row].transpose()))(0);
				}
			}

			// Construct Y matrix
			MatrixXd Y(1, numOfInTheMoney);
			for (int i = 0; i < numOfInTheMoney; i++)
			{
				int indexOfITM = inTheMoneyRowIndex[i];
				if (ind[indexOfITM] == -1)
					Y(0, i) = 0.0;
				else
				{
					Y(0, i) = expectedPayoffs[indexOfITM] * exp(-r * delta * (double)(ind[indexOfITM] - j));
				}

			}

			// Construct b matrix
			MatrixXd b(kTerm, 1);
			for (int i = 0; i < kTerm; i++)
				b(i, 0) = (Y * (fMatrixes[i].transpose()))(0);

			MatrixXd a = A.inverse() * b; // k * 1 matrix

			for (int i = 0; i < numOfInTheMoney; i++)
			{
				int indexOfITM = inTheMoneyRowIndex[i];
				double ECV = 0;
				for (int k = 0; k < kTerm; k++)
				{
					double t = a(k, 0) * BasisFunction(basisType, priceM[indexOfITM][j], k + 1);
					ECV += t;
				}

				double payoff = K / S0 - priceM[indexOfITM][j];
				if (payoff > ECV)
				{
					ind[indexOfITM] = j;
					expectedPayoffs[indexOfITM] = payoff;
				}
			}
			// clean memory
			delete[] fMatrixes;
			fMatrixes = NULL;
		}

		delete[] inTheMoneyRowIndex;
	}


	double sum = 0;
	for (int i = 0; i < numOfPaths; i++)
		if (ind[i] != -1)
			sum += exp(-1* r * delta * (double)(ind[i] + 1)) * expectedPayoffs[i];

	// clean memory
	for (int i = 0; i < numOfPaths; i++) delete[] priceM[i];
	delete[] priceM;
	delete[] ind; ind = NULL;
	delete[] expectedPayoffs; expectedPayoffs = NULL;

	return sum / (double)numOfPaths * S0;
}



double priceEuropeanForward(double S0, double r, double sigma, double T, double K, double t, Generater* g)
{
	int numOfPaths = 100000;
	int numOfInterval = 1000;
	double delta = T / (double)numOfInterval;
	double discountFactor = exp(-1 * r * delta);

	double* strikes = new double[numOfPaths];	
	double* payoffs = new double[numOfPaths];

	// Generate the entire path matrix
	MatrixXd priceM(numOfPaths, numOfInterval);

	for (int i = 0; i < numOfPaths; i = i + 2)
	{
		double* normals = g->generateDefaultNormal(numOfInterval);
		for (int j = 0; j < numOfInterval; j++)
		{
			double St = S0;
			if (j != 0)
				St = priceM(i, j - 1);
			priceM(i, j) = St + r * delta * St + sigma * St * sqrt(delta) * normals[j];
			priceM(i + 1, j) = St + r * delta * St - sigma * St * sqrt(delta) * normals[j];
			if (j * delta == t)
			{
				strikes[i] = priceM(i, j);
				strikes[i + 1] = priceM(i + 1, j);
			}
		}
		delete[] normals;
		normals = NULL;
	}
	priceM = priceM / S0;

	// Calculate payoff for Tn when n = numOfInterval 
	for (int i = 0; i < numOfPaths; i++)
	{
		double payoff = strikes[i] / S0 - priceM(i, numOfInterval - 1);
		if (payoff < 0)
		{
			payoff = 0;
		}
		payoffs[i] = payoff;
	}

	double sum = 0;
	discountFactor = pow(discountFactor, numOfInterval);
	for (int i = 0; i < numOfPaths; i++)
		sum = sum + discountFactor * payoffs[i];

	// clean memory
	delete[] strikes; strikes = NULL;
	delete[] payoffs; payoffs = NULL;
	return sum / (double)numOfPaths * S0;
}

double priceAmericanForward(double S0, double r, double sigma, double T, double K,
	int kTerm, int basisType, double t, Generater* g)
{
	int numOfPaths = 10000;
	int numOfInterval = 250;
	double delta = T / (double)numOfInterval;
	double discountFactor = exp(-1 * r * delta);

	int* ind = new int[numOfPaths];	// indexes
	double* expectedPayoffs = new double[numOfPaths];	// expected payoffs look up table
	double* strikes = new double[numOfPaths];

	// Generate the entire path matrix
	MatrixXd priceM(numOfPaths, numOfInterval);

	for (int i = 0; i < numOfPaths; i = i + 2)
	{
		double* normals = g->generateDefaultNormal(numOfInterval);
		for (int j = 0; j < numOfInterval; j++)
		{
			double St = S0;
			if (j != 0)
				St = priceM(i, j - 1);
			priceM(i, j) = St + r * delta * St + sigma * St * sqrt(delta) * normals[j];
			priceM(i + 1, j) = St + r * delta * St - sigma * St * sqrt(delta) * normals[j];
			if (j * delta == t)
			{
				strikes[i] = priceM(i, j);
				strikes[i + 1] = priceM(i + 1, j);
			}
		}
		delete[] normals;
		normals = NULL;
	}
	priceM = priceM / S0;


	// Calculate payoff for Tn when n = numOfInterval 
	for (int i = 0; i < numOfPaths; i++)
	{
		ind[i] = -1;
		expectedPayoffs[i] = 0;
		double payoff = strikes[i] / S0 - priceM(i, numOfInterval - 1);
		if (payoff > 0)
		{
			ind[i] = numOfInterval - 1;
			expectedPayoffs[i] = payoff;
		}

	}

	// For Tn when n is btw n and 0
	int stoptime = t / delta;
	for (int j = numOfInterval - 2; j > stoptime; j--)
	{
		std::vector<int> inTheMoneyIndex;
		for (int i = 0; i < numOfPaths; i++)
		{
			double payoff = strikes[i] / S0 - priceM(i, j);// Calculate EV
			if (payoff > 0)
				inTheMoneyIndex.push_back(i); // store all in the money indexes
		}

		int numOfInTheMoney = inTheMoneyIndex.size();

		// Construct f matrixes
		MatrixXd* fMatrixes = new MatrixXd[kTerm];
		for (int k = 0; k < kTerm; k++)
		{
			MatrixXd f(1, numOfInTheMoney);
			for (int i = 0; i < numOfInTheMoney; i++)
			{
				f(0, i) = BasisFunction(basisType, priceM(inTheMoneyIndex[i], j), k + 1);
			}
			fMatrixes[k] = f;
		}

		// Construct A matrix
		MatrixXd A(kTerm, kTerm);
		for (int row = 0; row < kTerm; row++)
		{
			for (int col = 0; col < kTerm; col++)
			{
				A(row, col) = (fMatrixes[col] * (fMatrixes[row].transpose()))(0);
			}
		}

		// Construct Y matrix
		MatrixXd Y(1, numOfInTheMoney);
		for (int i = 0; i < numOfInTheMoney; i++)
		{
			int indexOfITM = inTheMoneyIndex[i];
			if (ind[indexOfITM] == -1)
				Y(0, i) = 0.0;
			else
			{
				Y(0, i) = expectedPayoffs[indexOfITM] * pow(discountFactor, ind[indexOfITM] - j);
			}

		}

		// Construct b matrix
		MatrixXd b(kTerm, 1);
		for (int i = 0; i < kTerm; i++)
			b(i, 0) = (Y * (fMatrixes[i].transpose()))(0);

		MatrixXd a = A.inverse() * b; // k * 1 matrix

		for (int i = 0; i < numOfInTheMoney; i++)
		{
			int indexOfITM = inTheMoneyIndex[i];
			MatrixXd L(1, kTerm);
			for (int k = 0; k < kTerm; k++)
				L(0, k) = BasisFunction(basisType, priceM(indexOfITM, j), k + 1);
			double ECV = (L*a)(0);
			double payoff = K / S0 - priceM(indexOfITM, j);
			if (payoff > ECV)
			{
				ind[indexOfITM] = j;
				expectedPayoffs[indexOfITM] = payoff;
			}
		}
		// clean memory
		delete[] fMatrixes;
		fMatrixes = NULL;

	}

	double sum = 0;
	for (int i = 0; i < numOfPaths; i++)
		if (ind[i] != -1)
			sum = sum + pow(discountFactor, ind[i]) * expectedPayoffs[i];

	// clean memory
	delete[] ind; ind = NULL;
	delete[] expectedPayoffs; expectedPayoffs = NULL;
	delete[] strikes; strikes = NULL;
	return sum / (double)numOfPaths * S0;
}



int main()
{
	Generater* g = new Generater(2);
	double p = priceLSMC(36, 0.06, 0.2, 0.5, 40,3, 2, g);
	std::cout << p << std::endl;

	
	// Problem 1
	double price[3] = { 36,40,44 };
	double Maturity[3] = { 0.5,1.0,2.0 };
	double KTerm[3] = { 2,3,4 };

	// (a) Laguerre polynomials
	std::cout << "Using Laguerre:" << std::endl;


	for (int i = 0; i < 3; i++) // price
	{
		for (int j = 0; j < 3; j++) // maturity
		{
			for (int k = 0; k < 3; k++) // num of k terms
			{
				double p = priceLSMC(price[i], 0.06, 0.2, Maturity[j], 40, KTerm[k], 0, g);
				std::cout << "S_0 = " << price[i] << ", Maturity = " << Maturity[j] << ", Number of k = "
					<< KTerm[k] << " -> Price = " << p << std::endl;
			}
		}
	}

	// (b) Hermite polynomials
	std::cout << "Using Hermite:" << std::endl;
	for (int i = 0; i < 3; i++) // price
	{
		for (int j = 0; j < 3; j++) // maturity
		{
			for (int k = 0; k < 3; k++) // num of k terms
			{
				double p = priceLSMC(price[i], 0.06, 0.2, Maturity[j], 40, KTerm[k], 1, g);
				std::cout << "S_0 = " << price[i] << ", Maturity = " << Maturity[j] << ", Number of k = "
					<< KTerm[k] << " -> Price = " << p << std::endl;
			}
		}
	}

	// (b) Monomials  polynomials
	std::cout << "Using Monomials:" << std::endl;
	for (int i = 0; i < 3; i++) // price
	{
		for (int j = 0; j < 3; j++) // maturity
		{
			for (int k = 0; k < 3; k++) // num of k terms
			{
				double p = priceLSMC(price[i], 0.06, 0.2, Maturity[j], 40, KTerm[k], 2, g);
				std::cout << "S_0 = " << price[i] << ", Maturity = " << Maturity[j] << ", Number of k = "
					<< KTerm[k] << " -> Price = " << p << std::endl;
			}
		}
	}
	
	
	std::cout << "Problem 2:" << std::endl;
	std::cout << "Forward-start European put option: " << priceEuropeanForward(65, 0.06, 0.2, 1, 60, 0.2, g);
	std::cout << "Forward-start American put option: " << priceAmericanForward(65, 0.06, 0.2, 1, 60, 3, 1, 0.2, g);

	

}
 