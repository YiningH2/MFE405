data = read.delim("question2.txt",header = FALSE, dec = ".",nrows = 10000)
data = t(data)
hist(data,main = "Histogram for Question 2 - Discrete")

data = read.delim("question3.txt",header = FALSE, dec = ".")
data = t(data)
hist(data,main = "Histogram for Question 3 - Binomial")

data = read.delim("question4.txt",header = FALSE, dec = ".")
data = t(data)
hist(data,main = "Histogram for Question 4 - Exponential",breaks = 20)

