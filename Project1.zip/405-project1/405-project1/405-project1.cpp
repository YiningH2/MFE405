// 405-project1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#define _USE_MATH_DEFINES

#include <iostream>
#include <vector>
#include <random>
#include <time.h>
#include <fstream>
#include <math.h> 
#include <chrono> 


// Function to calculate the mean of an array, given the size
template <class T>
double calculateMean(T nums[], int total)
{
	double mean = 0;
	for (int i = 0; i < total; i++)
	{
		mean = mean + nums[i];
	}
	mean = mean / total;
	return mean;
}

// Function to calculate the sd of an array, given the size and mean
template <class T>
double calculateSD(T nums[], int total, double mean)
{
	double sd = 0;
	for (int i = 0; i < total; i++)
	{
		sd = sd + (nums[i] - mean) * (nums[i] - mean);
	}
	sd = sqrt(sd / total);
	return sd;
}

// Function to output data to a txt, given the filename, array and size
template <class T>
void outputFile(std::string filename, T arr[],int size)
{
	std::ofstream myfile(filename);
	if (myfile.is_open())
	{
		for (int count = 0; count < size; count++)
		{
			myfile << arr[count];
			if (count != (size - 1))
				myfile << "	";
		}
		myfile << '\n';
		myfile.close();
	}
}

// Function to calculate n choose k value
int nChoosek(int n, int k)
{
	if (k > n) return 0;
	if (k * 2 > n) k = n - k;
	if (k == 0) return 1;

	int result = n;
	for (int i = 2; i <= k; ++i) {
		result *= (n - i + 1);
		result /= i;
	}
	return result;
}

// Function to generate an array of Uniform RVs, given the seed and size
double* generateUniforms(int x_seed, int size)
{
	long long a = (long long)pow(7, 5);
	long long m = (long long)pow(2, 31) - 1;

	long long* nums = new long long[size]; // an array to store all values calculated
	nums[0] = (a * x_seed) % m;
	for (int i = 1; i < size; i++)
	{
		nums[i] = (a * nums[i - 1]) % m;
	}

	double* uniformNums = new double[size];
	for (int i = 0; i < size; i++)
	{
		// Divide by m to get the Uniforms btw 0 and 1
		uniformNums[i] = (double)nums[i] / (double)m;
	}
	// Clean the data
	delete[] nums;
	nums = NULL;
	return uniformNums;
}

int main()
{
	// Problem 1
	// (a)
	double* uniformNums = generateUniforms(1, 10000);

	// compute the mean
	double mean = calculateMean(uniformNums, 10000);
	// compute the sd
	double sd = calculateSD(uniformNums, 10000, mean);

	std::cout << "Problem 1:" << std::endl;
	std::cout << "(a) The Mean is " << mean << ", and the sd is " << sd << std::endl;

	// (b)
	std::default_random_engine generator;
	std::uniform_real_distribution<double> distribution(0.0, 1.0);
	generator.seed((unsigned int)time(0));	// set the seed to be current time

	static double uniformByBuiltIn[10000] = {};
	for (int i = 0; i < 10000; ++i) {
		double number = distribution(generator);
		uniformByBuiltIn[i] = number;
	}

	// compute the mean
	double mean_BuiltIn = calculateMean(uniformByBuiltIn, 10000);
	// compute the sd
	double sd_BuiltIn = calculateSD(uniformByBuiltIn, 10000, mean_BuiltIn);

	std::cout << "(b) The Mean is " << mean_BuiltIn << ", and the sd is " << sd_BuiltIn << std::endl;
	
	// ************************************************************
	// Problem 2
	// (a)
	int discreteDistribution[10000] = {};
	for (int i = 0; i < 10000; i++) 
	{
		double p = uniformNums[i];
		if (p < 0.3) 
		{
			discreteDistribution[i] = -1;
		} else if (p < (0.3+0.35)) 
		{
			discreteDistribution[i] = 0;
		}
		else if (p < (0.3 + 0.35 + 0.2)) 
		{
			discreteDistribution[i] = 1;
		}
		else
		{
			discreteDistribution[i] = 2;
		}
	}

	// (b)
	// Output the data  + Draw the graph in R
	outputFile("question2.txt", discreteDistribution, 10000);
	// Compute the mean
	double meanDiscrete = calculateMean(discreteDistribution, 10000);
	// compute the sd
	double sdDiscrete = calculateSD(discreteDistribution, 10000, meanDiscrete);
	std::cout << "Problem 2:" << std::endl;
	std::cout << "(b) The Mean is " << meanDiscrete << ", and the sd is " << sdDiscrete << std::endl;

	// ************************************************************
	// Problem 3
	// (a)
	int binomialDistribution[1000] = {};
	double prob = 0.64;
	// Generate 44,000 Uniform distributed numbers
	double* uniformP3 = generateUniforms(2, 44000);
	for (int i = 0; i < 1000; i++)
	{
		// For each binomial variable
		int sumOfUniform = 0;
		for (int k = 0; k < 44; k++)
		{
			// Sum up the bernuoli that are smaller than 0.64
			if (uniformP3[k+i*44] <= prob)	// i * 44 + k to access the corresponding Uniform
			{
				sumOfUniform = sumOfUniform + 1;
			}
		}
		binomialDistribution[i] = sumOfUniform;

	}

	// (b)
	// Output the data + Draw the graph in R
	outputFile("question3.txt", binomialDistribution, 1000);

	// Compute the probability that has X >= 40
	int counter = 0;
	for (int i = 0; i < 1000; i++) 
	{	
		if (binomialDistribution[i] >= 40)
			counter++; // count those that are larger than 40
	}
	std::cout << "Problem 3:" << std::endl;
	std::cout << "(b) The probability got from simulation is " << counter/1000.0 << std::endl;

	// According to Formula
	double pr_p3 = 0;
	for(int i = 40; i < 45; i++) {
		double curr = nChoosek(44, i) * pow(prob, i) * pow(1 - prob, 44 - i); 
		pr_p3 = pr_p3 + curr;
	}
	std::cout << "    The probability calculated is " << pr_p3 << std::endl;

	// CLean up memory
	delete[] uniformP3;
	uniformP3 = NULL;

	// ************************************************************
	// Problem 4
	// (a)
	double lamda = 1.5;
	static double expoDistribution[10000] = {};
	for (int i = 0; i < 10000; i++)
	{
		double temp = (-1) / lamda * log(1 - uniformNums[i]);
		expoDistribution[i] = temp;
	}

	// (b)
	// Compute the probability that has X >= 40
	int counterLargerThan1 = 0;
	int counterLargerThan4 = 0;  // count respectively those that are larger than 1 or 4
	for (int i = 0; i < 10000; i++) {
		if (expoDistribution[i] >= 4)
			counterLargerThan4++;
		else if (expoDistribution[i] >= 1)
			counterLargerThan1++;
	}

	std::cout << "Problem 4:" << std::endl;
	std::cout << "(b) The probability >= 1 is " << counterLargerThan1 / 10000.0 << 
		" , The probability >= 4 is " << counterLargerThan4 / 10000.0 << std::endl;

	// (c)
	// Compute the mean and sd, then output the data to graph in R
	mean = calculateMean(expoDistribution, 10000);
	std::cout << "(c) The Mean is " << mean << ", and the sd is " << calculateSD(expoDistribution, 10000, mean) << std::endl;
	// Output the data  + Draw the graph in R
	outputFile("question4.txt", expoDistribution, 10000);


	// ************************************************************
	// Problem 5
	// (a) Generate 5,000 Uniform distributed numbers
	int size_p5 = 5000;
	double* uniformP5 = generateUniforms(2, size_p5);

	// (b) Generate 5,000 Normally distributed, mean 0 and variance 1, by Box- Muller Method
	auto start = std::chrono::high_resolution_clock::now();
	static double normal_BoxMuller[5000] = {};
	for (int i = 0; i < size_p5 / 2; i ++)
	{
		double U1 = uniformP5[i];
		double U2 = uniformP5[size_p5 - 1 - i];
		double Z1 = sqrt(-2 * log(U1)) * cos(2 * M_PI * U2);
		double Z2 = sqrt(-2 * log(U1)) * sin(2 * M_PI * U2);
		normal_BoxMuller[i] = Z1;
		normal_BoxMuller[size_p5 - 1 - i] = Z2;
	}
	auto stop = std::chrono::high_resolution_clock::now();
	auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
	std::cout << "   The Box Muller method takes " << duration.count() << std::endl;

	// (c) Compute the empirical mean and the standard deviatio in (b)
	std::cout << "Problem 5:" << std::endl;
	mean = calculateMean(normal_BoxMuller, size_p5);
	std::cout << "(c) The Mean is " << mean << ", and the sd is " << 
		calculateSD(normal_BoxMuller,size_p5,mean) << std::endl;
	
	// (d) Polar-Marsaglia method 
	start = std::chrono::high_resolution_clock::now();
	static double normal_PM[5000] = {};
	int temp_total = size_p5;
	for (int i = 0; i < size_p5 / 2; i++)
	{
		double U1 = uniformP5[i];
		double U2 = uniformP5[size_p5 - 1 - i];
		double V1 = 2 * U1 - 1;
		double V2 = 2 * U2 - 1;
		double W = V1 * V1 + V2 * V2;
		double Z1 = NULL; 
		double Z2 = NULL;
		if (W < 1)
		{
			Z1 = V1 * sqrt((-2.0 * log(W)) / W);
			Z2 = V2 * sqrt((-2.0 * log(W)) / W);;
		} else 
		{ 
			temp_total = temp_total - 2; 
		}
		normal_PM[i] = Z1;
		normal_PM[size_p5 - 1 - i] = Z2;
	}
	stop = std::chrono::high_resolution_clock::now();
	duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
	std::cout << "   The Polar-Marsaglia method takes " << duration.count() << std::endl;

	// (e) Mean and SD
	mean = 0;
	for (int i = 0; i < size_p5; i++)
	{
		if (normal_PM[i] != NULL)
			mean = mean + normal_PM[i];
	}
	mean = mean / temp_total;

	sd = 0;
	for (int i = 0; i < size_p5; i++)
	{
		if (normal_PM[i] != NULL)
			sd = sd + (normal_PM[i] - mean) * (normal_PM[i] - mean);
	}
	sd = sqrt(sd / temp_total);

	std::cout << "(e) The Mean is " << mean << ", and the sd is " << sd << std::endl;

	// Clean the memory
	delete[] uniformNums;
	uniformNums = NULL;
	delete[] uniformP5;
	uniformP5 = NULL;

	return 0;
}